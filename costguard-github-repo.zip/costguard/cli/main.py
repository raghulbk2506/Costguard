﻿"""CostGuard CLI - Infrastructure Cost Impact Predictor."""

import json
import os
import shutil
import sys
from typing import Optional
import click
from rich.console import Console
from rich.table import Table

# Reconfigure stdout/stderr to UTF-8 on Windows
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

from costguard.core.cache import PricingCache
from costguard.core.calculator import CostCalculator
from costguard.core.parser import ParserError, TerraformPlanParser
from costguard.core.pricing import AzurePricingEngine

# Ensure console has sufficient width for the full table
term_width = max(shutil.get_terminal_size((100, 24)).columns, 105)
console = Console(width=term_width)
error_console = Console(stderr=True, width=term_width)


def format_currency(val: float, currency: str = "USD") -> str:
    sym = "$" if currency.upper() == "USD" else f"{currency} "
    return f"{sym}{val:.2f}"


def format_delta(val: float, currency: str = "USD") -> str:
    sym = "$" if currency.upper() == "USD" else f"{currency} "
    sign = "+" if val >= 0 else "-"
    return f"{sign}{sym}{abs(val):.2f}"


def render_terminal_report(result, currency: str):
    """Render the exact terminal output format specified by the handout."""
    console.print("=" * 99, style="bold cyan")
    console.print("COSTGUARD: Azure Infrastructure Cost Impact Report", style="bold white on navy_blue")
    console.print("=" * 99, style="bold cyan")

    table = Table(
        show_header=True,
        header_style="bold white",
        box=None,
        padding=(0, 2),
        collapse_padding=False,
    )
    table.add_column("Resource Address", style="cyan", no_wrap=False, min_width=34)
    table.add_column("Action", style="bold", min_width=8)
    table.add_column("Region", style="dim", min_width=10)
    table.add_column("SKU / Meter", min_width=25)
    table.add_column("Old ($/mo)", justify="right", min_width=11)
    table.add_column("New ($/mo)", justify="right", min_width=11)
    table.add_column("Delta ($/mo)", justify="right", min_width=12)

    for item in result.items:
        act = item.action.value.upper()
        if act == "CREATE":
            act_color = "green"
            delta_color = "bold green" if item.delta_monthly <= 0 else "bold red"
        elif act == "DELETE":
            act_color = "red"
            delta_color = "bold green"
        elif act == "UPDATE":
            act_color = "yellow"
            delta_color = "bold green" if item.delta_monthly < 0 else ("bold red" if item.delta_monthly > 0 else "white")
        else:
            act_color = "magenta"
            delta_color = "bold red" if item.delta_monthly > 0 else "bold green"

        table.add_row(
            item.address,
            f"[{act_color}]{act}[/{act_color}]",
            item.region,
            item.display_sku,
            format_currency(item.old_monthly, currency),
            format_currency(item.new_monthly, currency),
            f"[{delta_color}]{format_delta(item.delta_monthly, currency)}[/{delta_color}]",
        )

    console.print(table)
    console.print("-" * 99, style="cyan")

    # Financial summary
    hits_word = "hit" if result.cache_hits == 1 else "hits"
    lookup_word = "lookup" if result.api_calls == 1 else "lookups"
    cache_info = f"[Cache: {result.cache_hits} {hits_word}, {result.api_calls} API {lookup_word}]"

    delta_color = "bold green" if result.net_delta <= 0 else "bold red"
    console.print("FINANCIAL SUMMARY:", style="bold white")
    console.print(f"  Prior Monthly Total:     {format_currency(result.prior_total, currency)}/mo")
    console.print(f"  Projected Monthly Total: {format_currency(result.projected_total, currency)}/mo")
    console.print(f"  Net Monthly Impact:      [{delta_color}]{format_delta(result.net_delta, currency)}/mo[/{delta_color}]  {cache_info}")
    console.print("-" * 99, style="cyan")

    # Policy verdict
    console.print("POLICY VERDICT:", style="bold white")
    console.print(f"  Budget Threshold:        +{format_currency(result.verdict.max_increase, currency)}/mo")

    if result.verdict.passed:
        console.print(f"  Status:                  [bold green]PASSED[/bold green] (Within budget allowance)")
        console.print("=" * 99, style="bold cyan")
    else:
        console.print(f"  Status:                  [bold red]FAILED[/bold red] (Exceeds budget allowance by +{format_currency(result.verdict.overage, currency)}/mo)")
        console.print("[bold red][CIRCUIT BREAKER] CostGuard: Budget threshold breached. Deployment blocked.[/bold red]")
        console.print("=" * 99, style="bold red")


def render_markdown_report(result, currency: str):
    """Render markdown table suitable for GitHub Pull Request comments."""
    lines = [
        "## CostGuard: Azure Infrastructure Cost Impact Report\n",
        f"| Resource Address | Action | Region | SKU / Meter | Old ({currency}/mo) | New ({currency}/mo) | Delta ({currency}/mo) |",
        "| :--- | :--- | :--- | :--- | ---: | ---: | ---: |",
    ]
    for it in result.items:
        lines.append(
            f"| `{it.address}` | **{it.action.value.upper()}** | `{it.region}` | {it.display_sku} | "
            f"{format_currency(it.old_monthly, currency)} | {format_currency(it.new_monthly, currency)} | "
            f"{format_delta(it.delta_monthly, currency)} |"
        )
    lines.append("")
    lines.append("### Financial Summary")
    lines.append(f"- **Prior Monthly Total:** {format_currency(result.prior_total, currency)}/mo")
    lines.append(f"- **Projected Monthly Total:** {format_currency(result.projected_total, currency)}/mo")
    lines.append(f"- **Net Monthly Impact:** {format_delta(result.net_delta, currency)}/mo (`{result.cache_hits}` cache hits, `{result.api_calls}` API lookups)")
    lines.append("")
    lines.append("### Policy Verdict")
    lines.append(f"- **Budget Threshold:** +{format_currency(result.verdict.max_increase, currency)}/mo")
    if result.verdict.passed:
        lines.append("- **Status:** **PASSED** (Within budget allowance)")
    else:
        lines.append(f"- **Status:** **FAILED** (Exceeds budget allowance by +{format_currency(result.verdict.overage, currency)}/mo)")
        lines.append("\n> **[CIRCUIT BREAKER] Deployment Blocked.**")

    console.print("\n".join(lines))


@click.command(context_settings=dict(help_option_names=["-h", "--help"]))
@click.option("--plan", "-p", "plan_file", type=click.Path(exists=False), help="Path to Terraform Plan JSON file.")
@click.option("--max-increase", "-m", default=50.0, type=float, show_default=True, help="Maximum allowed monthly cost increase before failing.")
@click.option("--currency", "-c", default="USD", show_default=True, help="Billing currency code (USD, EUR, GBP, INR).")
@click.option("--clear-cache", is_flag=True, help="Purge SQLite pricing cache before evaluation.")
@click.option("--markdown", is_flag=True, help="Render markdown output for CI/CD PR comments.")
@click.option("--json", "json_output", is_flag=True, help="Output raw JSON results.")
def main(
    plan_file: Optional[str],
    max_increase: float,
    currency: str,
    clear_cache: bool,
    markdown: bool,
    json_output: bool,
):
    """CostGuard: Infrastructure Cost Firewall for Terraform Plans.

    Analyzes compiled Terraform plan JSON, queries Azure Retail Prices API with SQLite caching,
    calculates monthly cost deltas (730 hours), and strictly enforces budget thresholds.
    """
    cache = PricingCache()
    if clear_cache:
        deleted = cache.clear()
        if not json_output:
            console.print(f"[yellow][INFO] Cleared {deleted} entries from SQLite pricing cache.[/yellow]")

    # 1. Read input from --plan flag or stdin
    plan_raw = ""
    if plan_file:
        if not os.path.exists(plan_file):
            error_console.print(f"[bold red]Error: Plan file not found: '{plan_file}'[/bold red]")
            sys.exit(2)
        try:
            with open(plan_file, "r", encoding="utf-8") as f:
                plan_raw = f.read()
        except Exception as e:
            error_console.print(f"[bold red]Error reading plan file: {e}[/bold red]")
            sys.exit(2)
    else:
        # Check standard input
        if not sys.stdin.isatty():
            try:
                plan_raw = sys.stdin.read()
            except Exception as e:
                error_console.print(f"[bold red]Error reading stdin: {e}[/bold red]")
                sys.exit(2)
        else:
            error_console.print("[bold red]Error: No Terraform plan provided. Pass --plan <file> or pipe via stdin.[/bold red]")
            error_console.print("Example: terraform show -json tfplan.binary | costguard --max-increase 50")
            sys.exit(2)

    if not plan_raw.strip():
        error_console.print("[bold red]Error: Received empty Terraform plan input.[/bold red]")
        sys.exit(2)

    # 2. Parse Terraform Plan JSON
    try:
        plan_dict = TerraformPlanParser.parse_json(plan_raw)
        billable, skipped = TerraformPlanParser.parse_plan(plan_dict)
    except ParserError as pe:
        error_console.print(f"[bold red]Error: {pe}[/bold red]")
        sys.exit(2)
    except Exception as ex:
        error_console.print(f"[bold red]Unexpected Parser Error: {ex}[/bold red]")
        sys.exit(2)

    # Print skipped non-billable warnings
    if not json_output and not markdown:
        for sk in skipped:
            console.print(f"[dim][INFO] Skipping non-billable resource: {sk['address']}[/dim]")

    # 3. Pricing & Calculations
    pricing_engine = AzurePricingEngine(cache=cache)
    calculator = CostCalculator(pricing_engine=pricing_engine)

    try:
        result = calculator.analyze_plan(
            billable_resources=billable,
            skipped_resources=skipped,
            max_increase=max_increase,
            currency=currency,
        )
    except Exception as ce:
        error_console.print(f"[bold red]Calculation Engine Error: {ce}[/bold red]")
        sys.exit(2)

    # 4. Render output
    if json_output:
        print(result.model_dump_json(indent=2))
    elif markdown:
        render_markdown_report(result, currency)
    else:
        render_terminal_report(result, currency)

    # 5. Exit with strict circuit breaker code
    sys.exit(result.verdict.exit_code)


if __name__ == "__main__":
    main()
