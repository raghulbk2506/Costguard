﻿"""SQLite write-through cache for Azure Retail Pricing."""

import os
import sqlite3
import time
from typing import List, Optional
from .models import CacheEntry, CacheStats, PriceRate, PricingSource


DEFAULT_DB_PATH = os.environ.get("COSTGUARD_CACHE_PATH", "pricing_cache.db")


class PricingCache:
    """Embedded SQLite write-through cache."""

    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path or os.environ.get("COSTGUARD_CACHE_PATH", DEFAULT_DB_PATH)
        self.hits = 0
        self.misses = 0
        self.api_calls = 0
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        """Create table and index if they do not exist."""
        # Ensure directory exists if path has dir
        dir_name = os.path.dirname(self.db_path)
        if dir_name:
            os.makedirs(dir_name, exist_ok=True)

        with self._get_connection() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS pricing_cache (
                    sku TEXT NOT NULL,
                    region TEXT NOT NULL,
                    currency TEXT NOT NULL DEFAULT 'USD',
                    hourly_rate REAL NOT NULL,
                    cached_at INTEGER NOT NULL,
                    meter_name TEXT,
                    product_name TEXT,
                    PRIMARY KEY (sku, region, currency)
                );
                """
            )
            conn.commit()

    def get(self, sku: str, region: str, currency: str = "USD") -> Optional[PriceRate]:
        """Look up price from SQLite. Returns PriceRate if found, else None."""
        norm_sku = sku.strip()
        norm_region = region.strip().lower()
        norm_currency = currency.strip().upper()

        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT sku, region, currency, hourly_rate, cached_at, meter_name, product_name
                FROM pricing_cache
                WHERE LOWER(sku) = LOWER(?) AND LOWER(region) = LOWER(?) AND UPPER(currency) = ?
                """,
                (norm_sku, norm_region, norm_currency),
            )
            row = cursor.fetchone()
            if row:
                self.hits += 1
                hourly = float(row["hourly_rate"])
                monthly = hourly * 730.0
                return PriceRate(
                    sku=row["sku"],
                    region=row["region"],
                    currency=row["currency"],
                    hourly_rate=hourly,
                    monthly_rate=round(monthly, 4),
                    meter_name=row["meter_name"] or "",
                    product_name=row["product_name"] or "",
                    source=PricingSource.CACHE,
                    cached_at=row["cached_at"],
                )

        self.misses += 1
        return None

    def set(self, rate: PriceRate):
        """Write-through store price in SQLite."""
        now = int(time.time())
        with self._get_connection() as conn:
            conn.execute(
                """
                INSERT INTO pricing_cache (sku, region, currency, hourly_rate, cached_at, meter_name, product_name)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(sku, region, currency) DO UPDATE SET
                    hourly_rate = excluded.hourly_rate,
                    cached_at = excluded.cached_at,
                    meter_name = excluded.meter_name,
                    product_name = excluded.product_name
                """,
                (
                    rate.sku,
                    rate.region.lower(),
                    rate.currency.upper(),
                    rate.hourly_rate,
                    now,
                    rate.meter_name,
                    rate.product_name,
                ),
            )
            conn.commit()

    def record_api_call(self):
        """Increment count of live API calls made."""
        self.api_calls += 1

    def count(self) -> int:
        """Return total number of cached records."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM pricing_cache")
            return cursor.fetchone()[0]

    def get_all(self, limit: int = 100, offset: int = 0, search: Optional[str] = None) -> List[CacheEntry]:
        """List cached entries for Explorer and Management table."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            if search:
                term = f"%{search}%"
                cursor.execute(
                    """
                    SELECT sku, region, currency, hourly_rate, cached_at, meter_name, product_name
                    FROM pricing_cache
                    WHERE sku LIKE ? OR region LIKE ? OR product_name LIKE ?
                    ORDER BY cached_at DESC LIMIT ? OFFSET ?
                    """,
                    (term, term, term, limit, offset),
                )
            else:
                cursor.execute(
                    """
                    SELECT sku, region, currency, hourly_rate, cached_at, meter_name, product_name
                    FROM pricing_cache
                    ORDER BY cached_at DESC LIMIT ? OFFSET ?
                    """,
                    (limit, offset),
                )
            rows = cursor.fetchall()
            return [
                CacheEntry(
                    sku=r["sku"],
                    region=r["region"],
                    currency=r["currency"],
                    hourly_rate=r["hourly_rate"],
                    cached_at=r["cached_at"],
                    meter_name=r["meter_name"],
                    product_name=r["product_name"],
                )
                for r in rows
            ]

    def clear(self) -> int:
        """Purge all entries from the pricing cache."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM pricing_cache")
            deleted = cursor.rowcount
            conn.commit()
            return deleted

    def get_stats(self) -> CacheStats:
        """Return cache metadata metrics."""
        total = self.count()
        total_lookups = self.hits + self.misses
        hit_rate = (self.hits / total_lookups * 100.0) if total_lookups > 0 else 0.0

        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT MAX(cached_at) FROM pricing_cache")
            last_updated = cursor.fetchone()[0]

        return CacheStats(
            total_entries=total,
            cache_hits=self.hits,
            cache_misses=self.misses,
            api_calls=self.api_calls,
            hit_rate_pct=round(hit_rate, 1),
            last_updated=last_updated,
        )
