﻿"""Monthly cost and financial delta calculation engine."""

import time
from typing import List, Optional, Tuple
from .cache import PricingCache
from .models import (
    ActionType,
    ExtractedResource,
    PlanAnalysisResult,
    PolicyVerdict,
    ResourceCostItem,
)
from .pricing import AzurePricingEngine
from .resources import determine_disk_tier


HOURS_PER_MONTH = 730.0


class CostCalculator:
    """Calculates monthly costs and deltas using 730-hour baseline."""

    def __init__(self, pricing_engine: Optional[AzurePricingEngine] = None):
        self.pricing_engine = pricing_engine or AzurePricingEngine()

    def calculate_resource_cost(
        self,
        resource: ExtractedResource,
        currency: str = "USD",
        use_cache: bool = True,
    ) -> Tuple[ResourceCostItem, List[str]]:
        """Calculate Old, New, and Delta monthly cost for a single resource change."""
        warnings: List[str] = []
        old_hourly = 0.0
        new_hourly = 0.0
        old_monthly = 0.0
        new_monthly = 0.0
        display_sku = ""

        # Format display name helper for disks
        def format_sku_display(res_type: str, sku_str: Optional[str], size_gb: Optional[int], storage_type: Optional[str]) -> str:
            if not sku_str:
                return "Unknown"
            if "managed_disk" in res_type:
                _, disp = determine_disk_tier(storage_type, size_gb)
                return disp
            return sku_str

        # 1. CREATE action
        if resource.action == ActionType.CREATE:
            display_sku = format_sku_display(resource.resource_type, resource.sku, resource.disk_size_gb, resource.storage_account_type)
            if resource.sku:
                rate, warn = self.pricing_engine.get_price(
                    sku=resource.sku,
                    region=resource.region or "eastus",
                    currency=currency,
                    os_type=resource.os_type or "Linux",
                    resource_type=resource.resource_type,
                    use_cache=use_cache,
                )
                if warn:
                    warnings.append(warn)
                new_hourly = rate.hourly_rate
                new_monthly = new_hourly * HOURS_PER_MONTH
            old_hourly = 0.0
            old_monthly = 0.0

        # 2. DELETE action
        elif resource.action == ActionType.DELETE:
            sku_to_price = resource.old_sku or resource.sku
            display_sku = format_sku_display(resource.resource_type, sku_to_price, resource.disk_size_gb, resource.storage_account_type)
            if sku_to_price:
                rate, warn = self.pricing_engine.get_price(
                    sku=sku_to_price,
                    region=resource.old_region or resource.region or "eastus",
                    currency=currency,
                    os_type=resource.os_type or "Linux",
                    resource_type=resource.resource_type,
                    use_cache=use_cache,
                )
                if warn:
                    warnings.append(warn)
                old_hourly = rate.hourly_rate
                old_monthly = old_hourly * HOURS_PER_MONTH
            new_hourly = 0.0
            new_monthly = 0.0

        # 3. UPDATE or REPLACE action
        else:
            old_sku = resource.old_sku or resource.sku
            new_sku = resource.sku or resource.old_sku

            disp_old = format_sku_display(resource.resource_type, old_sku, resource.disk_size_gb, resource.storage_account_type)
            disp_new = format_sku_display(resource.resource_type, new_sku, resource.disk_size_gb, resource.storage_account_type)

            if old_sku == new_sku and resource.old_region == resource.region:
                display_sku = disp_new
            else:
                display_sku = f"{disp_old} -> {disp_new}"

            if old_sku:
                rate_old, warn_old = self.pricing_engine.get_price(
                    sku=old_sku,
                    region=resource.old_region or resource.region or "eastus",
                    currency=currency,
                    os_type=resource.os_type or "Linux",
                    resource_type=resource.resource_type,
                    use_cache=use_cache,
                )
                if warn_old:
                    warnings.append(warn_old)
                old_hourly = rate_old.hourly_rate
                old_monthly = old_hourly * HOURS_PER_MONTH

            if new_sku:
                rate_new, warn_new = self.pricing_engine.get_price(
                    sku=new_sku,
                    region=resource.region or resource.old_region or "eastus",
                    currency=currency,
                    os_type=resource.os_type or "Linux",
                    resource_type=resource.resource_type,
                    use_cache=use_cache,
                )
                if warn_new:
                    warnings.append(warn_new)
                new_hourly = rate_new.hourly_rate
                new_monthly = new_hourly * HOURS_PER_MONTH

            # Check for metadata-only update (tags/description changed, but SKU/region didn't)
            if old_sku == new_sku and resource.old_region == resource.region:
                # Delta must be exactly 0.00
                old_monthly = new_monthly

        delta_monthly = new_monthly - old_monthly

        item = ResourceCostItem(
            address=resource.address,
            resource_type=resource.resource_type,
            action=resource.action,
            region=resource.region or "eastus",
            old_sku=resource.old_sku,
            new_sku=resource.sku,
            display_sku=display_sku,
            old_hourly=round(old_hourly, 6),
            new_hourly=round(new_hourly, 6),
            old_monthly=round(old_monthly, 2),
            new_monthly=round(new_monthly, 2),
            delta_monthly=round(delta_monthly, 2),
            tags=resource.tags,
            is_billable=True,
            warning="; ".join(warnings) if warnings else None,
        )
        return item, warnings

    def analyze_plan(
        self,
        billable_resources: List[ExtractedResource],
        skipped_resources: List[dict],
        max_increase: float = 50.0,
        currency: str = "USD",
        use_cache: bool = True,
    ) -> PlanAnalysisResult:
        """Run complete cost analysis across all extracted resources."""
        start_time = time.time()
        initial_hits = self.pricing_engine.cache.hits
        initial_calls = self.pricing_engine.cache.api_calls

        items: List[ResourceCostItem] = []
        all_warnings: List[str] = []

        for res in billable_resources:
            item, warns = self.calculate_resource_cost(res, currency=currency, use_cache=use_cache)
            items.append(item)
            all_warnings.extend(warns)

        prior_total = round(sum(it.old_monthly for it in items), 2)
        projected_total = round(sum(it.new_monthly for it in items), 2)
        net_delta = round(projected_total - prior_total, 2)

        cache_hits = self.pricing_engine.cache.hits - initial_hits
        api_calls = self.pricing_engine.cache.api_calls - initial_calls
        duration_ms = round((time.time() - start_time) * 1000.0, 2)

        # Budget verdict
        passed = net_delta <= max_increase
        overage = round(net_delta - max_increase, 2) if not passed else 0.0

        if passed:
            status_text = "PASSED (Within budget allowance)"
            exit_code = 0
        else:
            status_text = f"FAILED (Exceeds budget allowance by +${overage:.2f}/mo)"
            exit_code = 1

        verdict = PolicyVerdict(
            max_increase=max_increase,
            passed=passed,
            status_text=status_text,
            exit_code=exit_code,
            overage=overage,
        )

        return PlanAnalysisResult(
            items=items,
            prior_total=prior_total,
            projected_total=projected_total,
            net_delta=net_delta,
            currency=currency,
            verdict=verdict,
            cache_hits=cache_hits,
            api_calls=api_calls,
            duration_ms=duration_ms,
            skipped_resources=skipped_resources,
            warnings=all_warnings,
        )
