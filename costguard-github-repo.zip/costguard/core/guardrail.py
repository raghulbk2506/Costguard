﻿"""Policy guardrail and circuit breaker evaluation."""

from typing import Dict, Any
from .models import PolicyVerdict


class BudgetGuardrail:
    """Evaluates cost deltas against financial guardrails."""

    def __init__(self, max_increase: float = 50.0, warning_pct: float = 80.0):
        self.max_increase = max_increase
        self.warning_pct = warning_pct

    def evaluate(self, net_delta: float) -> PolicyVerdict:
        """Evaluate net monthly increase against budget limit."""
        passed = net_delta <= self.max_increase
        overage = round(net_delta - self.max_increase, 2) if not passed else 0.0

        if passed:
            status_text = "PASSED (Within budget allowance)"
            exit_code = 0
        else:
            status_text = f"FAILED (Exceeds budget allowance by +${overage:.2f}/mo)"
            exit_code = 1

        return PolicyVerdict(
            max_increase=self.max_increase,
            passed=passed,
            status_text=status_text,
            exit_code=exit_code,
            overage=overage,
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "max_increase": self.max_increase,
            "warning_threshold_pct": self.warning_pct,
            "enforcement_action": "BLOCK_DEPLOYMENT",
        }
