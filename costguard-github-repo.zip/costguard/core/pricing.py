﻿"""Azure Retail Prices API Client with non-spot filtering and cache integration."""

import logging
import os
import urllib.parse
from typing import Optional, Tuple
import httpx

from .cache import PricingCache
from .models import PriceRate, PricingSource

logger = logging.getLogger("costguard.pricing")
DEFAULT_TIMEOUT = float(os.environ.get("COSTGUARD_API_TIMEOUT", "8.0"))
AZURE_PRICES_URL = "https://prices.azure.com/api/retail/prices"


class AzurePricingEngine:
    """Queries Azure Retail Prices REST API with cache-first strategy."""

    def __init__(self, cache: Optional[PricingCache] = None, timeout: float = DEFAULT_TIMEOUT):
        self.cache = cache or PricingCache()
        self.timeout = timeout

    def get_price(
        self,
        sku: str,
        region: str,
        currency: str = "USD",
        os_type: str = "Linux",
        resource_type: str = "virtual_machine",
        use_cache: bool = True,
    ) -> Tuple[PriceRate, Optional[str]]:
        """Retrieve rate for resource SKU in region.
        
        Returns (PriceRate, warning_message_or_None).
        """
        sku_clean = sku.strip()
        region_clean = region.strip().lower()
        currency_clean = currency.strip().upper()

        # 1. Check SQLite write-through cache first
        if use_cache:
            cached_rate = self.cache.get(sku_clean, region_clean, currency_clean)
            if cached_rate:
                return cached_rate, None

        # 2. Cache miss -> query live Azure Retail Prices REST API
        self.cache.record_api_call()
        try:
            rate, warning = self._fetch_live_azure_price(
                sku=sku_clean,
                region=region_clean,
                currency=currency_clean,
                os_type=os_type,
                resource_type=resource_type,
            )
            # 3. Store result in cache if found
            if rate and rate.hourly_rate > 0:
                self.cache.set(rate)
            return rate, warning

        except (httpx.TimeoutException, httpx.NetworkError, httpx.ConnectError) as exc:
            warn = f"[WARN] Network unavailable; defaulting SKU '{sku_clean}' to $0.00."
            fallback = PriceRate(
                sku=sku_clean,
                region=region_clean,
                currency=currency_clean,
                hourly_rate=0.0,
                monthly_rate=0.0,
                meter_name="offline-fallback",
                product_name="offline-fallback",
                source=PricingSource.FALLBACK,
            )
            return fallback, warn
        except Exception as exc:
            warn = f"[WARN] Error querying Azure API for SKU '{sku_clean}': {str(exc)}"
            fallback = PriceRate(
                sku=sku_clean,
                region=region_clean,
                currency=currency_clean,
                hourly_rate=0.0,
                monthly_rate=0.0,
                meter_name="error-fallback",
                product_name="error-fallback",
                source=PricingSource.FALLBACK,
            )
            return fallback, warn

    def _fetch_live_azure_price(
        self,
        sku: str,
        region: str,
        currency: str,
        os_type: str,
        resource_type: str,
    ) -> Tuple[PriceRate, Optional[str]]:
        """Fetch live price from Azure Retail Prices API with OData filter."""
        headers = {
            "User-Agent": "CostGuard-FinOps/1.0",
            "Accept": "application/json",
        }

        # Build query parameters
        params = {
            "currencyCode": f"'{currency}'",
        }

        if "disk" in resource_type.lower() or "disk" in sku.lower():
            # Managed Disk query
            # Extract disk tier like P10, S10, E10
            tier_match = sku.replace("Premium_SSD_Managed_Disk_", "").replace("Standard_SSD_Managed_Disk_", "").replace("Standard_HDD_Managed_Disk_", "")
            filter_str = (
                f"serviceName eq 'Storage' and armRegionName eq '{region}' and "
                f"priceType eq 'Consumption' and contains(meterName, '{tier_match}')"
            )
        else:
            # Virtual Machine query
            filter_str = (
                f"serviceName eq 'Virtual Machines' and armRegionName eq '{region}' and "
                f"armSkuName eq '{sku}' and priceType eq 'Consumption'"
            )

        params["$filter"] = filter_str

        with httpx.Client(timeout=self.timeout) as client:
            resp = client.get(AZURE_PRICES_URL, params=params, headers=headers)
            if resp.status_code != 200:
                warn = f"[WARN] Azure Retail API returned HTTP {resp.status_code} for SKU '{sku}'."
                return (
                    PriceRate(
                        sku=sku,
                        region=region,
                        currency=currency,
                        hourly_rate=0.0,
                        monthly_rate=0.0,
                        source=PricingSource.LIVE_API,
                    ),
                    warn,
                )

            data = resp.json()
            items = data.get("Items", [])

            if not items:
                # Try fallback query without region filter if region-specific didn't return
                warn = f"[WARN] SKU '{sku}' not found in Azure Retail API. Skipping."
                return (
                    PriceRate(
                        sku=sku,
                        region=region,
                        currency=currency,
                        hourly_rate=0.0,
                        monthly_rate=0.0,
                        source=PricingSource.LIVE_API,
                    ),
                    warn,
                )

            # Filter items:
            # Mandatory rule: exclude Spot and Low Priority meters
            filtered = []
            for item in items:
                mname = item.get("meterName", "")
                pname = item.get("productName", "")
                arm_sku = item.get("armSkuName", "")

                # Exclude Spot and Low Priority
                if "spot" in mname.lower() or "low priority" in mname.lower() or "spot" in arm_sku.lower():
                    continue

                if "disk" in resource_type.lower() or "disk" in sku.lower():
                    # Exclude mounts, snapshots, ZRS (unless specified)
                    if "mount" in mname.lower() or "snapshot" in mname.lower():
                        continue
                    if "zrs" in mname.lower():
                        continue
                    filtered.append(item)
                else:
                    # Virtual Machine OS matching
                    is_windows_product = "windows" in pname.lower()
                    if os_type.lower() == "windows":
                        if is_windows_product:
                            filtered.append(item)
                    else:
                        # Linux: exclude Windows meters
                        if not is_windows_product:
                            filtered.append(item)

            if not filtered:
                # Fallback to any non-spot item if strict filter was too tight
                for item in items:
                    mname = item.get("meterName", "")
                    if "spot" not in mname.lower() and "low priority" not in mname.lower():
                        filtered.append(item)
                        break

            if not filtered:
                warn = f"[WARN] SKU '{sku}' had no standard consumption meters in Azure Retail API."
                return (
                    PriceRate(
                        sku=sku,
                        region=region,
                        currency=currency,
                        hourly_rate=0.0,
                        monthly_rate=0.0,
                        source=PricingSource.LIVE_API,
                    ),
                    warn,
                )

            # Select chosen item
            best = filtered[0]
            raw_price = float(best.get("retailPrice", 0.0))
            unit = best.get("unitOfMeasure", "1 Hour")

            if "month" in unit.lower():
                # E.g. disk retail price is per month ($19.71/mo)
                monthly = raw_price
                hourly = raw_price / 730.0
            else:
                # Standard hourly rate
                hourly = raw_price
                monthly = hourly * 730.0

            rate = PriceRate(
                sku=sku,
                region=region,
                currency=best.get("currencyCode", currency),
                hourly_rate=round(hourly, 6),
                monthly_rate=round(monthly, 4),
                meter_name=best.get("meterName", ""),
                product_name=best.get("productName", ""),
                unit_of_measure=unit,
                source=PricingSource.LIVE_API,
            )
            return rate, None
