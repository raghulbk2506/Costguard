﻿"""Terraform Plan JSON parser."""

import json
from typing import Any, Dict, List, Tuple
from .models import ExtractedResource
from .resources import extract_resource_details


class ParserError(Exception):
    """Raised when plan JSON is invalid or cannot be parsed."""
    pass


class TerraformPlanParser:
    """Parses Terraform Plan JSON and extracts resource change descriptors."""

    @staticmethod
    def parse_json(json_content: str) -> Dict[str, Any]:
        """Parse raw JSON string safely."""
        if not json_content or not json_content.strip():
            raise ParserError("Terraform plan input is empty.")
        try:
            return json.loads(json_content)
        except json.JSONDecodeError as exc:
            raise ParserError(f"Invalid Terraform JSON: {str(exc)}")

    @classmethod
    def parse_plan(cls, plan_data: Dict[str, Any]) -> Tuple[List[ExtractedResource], List[Dict[str, str]]]:
        """Extract all resources from resource_changes array.
        
        Returns (billable_resources, skipped_resources).
        """
        if not isinstance(plan_data, dict):
            raise ParserError("Invalid plan format: Root element must be a JSON object.")

        resource_changes = plan_data.get("resource_changes", [])
        if not isinstance(resource_changes, list):
            raise ParserError("Invalid plan format: 'resource_changes' must be an array.")

        billable: List[ExtractedResource] = []
        skipped: List[Dict[str, str]] = []

        for change in resource_changes:
            if not isinstance(change, dict):
                continue

            extracted = extract_resource_details(change)

            # Skip no-op changes
            if extracted.action.value == "no-op":
                continue

            if extracted.is_billable:
                billable.append(extracted)
            else:
                skipped.append({
                    "address": extracted.address,
                    "type": extracted.resource_type,
                    "reason": extracted.skip_reason or "Non-billable resource type",
                })

        return billable, skipped
