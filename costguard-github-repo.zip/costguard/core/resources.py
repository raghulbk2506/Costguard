﻿"""Azure resource extraction, normalization, and categorization."""

import re
from typing import Any, Dict, List, Optional, Tuple
from .models import ActionType, ExtractedResource


NON_BILLABLE_TYPES = {
    "azurerm_resource_group",
    "azurerm_virtual_network",
    "azurerm_subnet",
    "azurerm_network_security_group",
    "azurerm_network_security_rule",
    "azurerm_route_table",
    "azurerm_route",
    "azurerm_network_interface",
    "azurerm_role_assignment",
    "azurerm_role_definition",
    "azurerm_management_lock",
    "azurerm_private_dns_zone",
    "azurerm_private_endpoint",
}

BILLABLE_TYPES = {
    "azurerm_linux_virtual_machine",
    "azurerm_windows_virtual_machine",
    "azurerm_virtual_machine",
    "azurerm_managed_disk",
}


def normalize_region(region: Optional[str]) -> str:
    """Normalize Azure region names, e.g. 'East US' -> 'eastus'."""
    if not region:
        return "eastus"
    # Remove all spaces, dashes, underscores, and lowercase
    cleaned = re.sub(r"[\s\-_]", "", region).lower()
    return cleaned


def determine_disk_tier(storage_type: Optional[str], size_gb: Optional[int]) -> Tuple[str, str]:
    """Map managed disk storage_account_type and size to Azure SKU and display name.
    
    Returns (sku_name, display_name).
    e.g. ('Premium_SSD_Managed_Disk_P10', 'P10 Premium SSD (128GB)')
    """
    size = size_gb or 128
    stype = (storage_type or "Premium_LRS").upper()

    if "PREMIUM" in stype:
        if size <= 32:
            tier = "P4"
        elif size <= 64:
            tier = "P6"
        elif size <= 128:
            tier = "P10"
        elif size <= 256:
            tier = "P15"
        elif size <= 512:
            tier = "P20"
        elif size <= 1024:
            tier = "P30"
        elif size <= 2048:
            tier = "P40"
        else:
            tier = "P50"
        sku = f"Premium_SSD_Managed_Disk_{tier}"
        display = f"{tier} Premium SSD ({size}GB)"
        return sku, display

    elif "STANDARDSSD" in stype:
        if size <= 32:
            tier = "E4"
        elif size <= 64:
            tier = "E6"
        elif size <= 128:
            tier = "E10"
        elif size <= 256:
            tier = "E15"
        elif size <= 512:
            tier = "E20"
        elif size <= 1024:
            tier = "E30"
        else:
            tier = "E40"
        sku = f"Standard_SSD_Managed_Disk_{tier}"
        display = f"{tier} Standard SSD ({size}GB)"
        return sku, display

    else:
        # Standard HDD
        if size <= 32:
            tier = "S4"
        elif size <= 64:
            tier = "S6"
        elif size <= 128:
            tier = "S10"
        elif size <= 256:
            tier = "S15"
        elif size <= 512:
            tier = "S20"
        elif size <= 1024:
            tier = "S30"
        else:
            tier = "S40"
        sku = f"Standard_HDD_Managed_Disk_{tier}"
        display = f"{tier} Standard HDD ({size}GB)"
        return sku, display


def extract_resource_details(change: Dict[str, Any]) -> ExtractedResource:
    """Extract and normalize resource information from a Terraform resource_change item."""
    address = change.get("address", "unknown.resource")
    rtype = change.get("type", "unknown")
    actions = change.get("change", {}).get("actions", [])
    before = change.get("change", {}).get("before") or {}
    after = change.get("change", {}).get("after") or {}

    # Map action
    if actions == ["create"]:
        action_type = ActionType.CREATE
    elif actions == ["delete"]:
        action_type = ActionType.DELETE
    elif actions == ["update"]:
        action_type = ActionType.UPDATE
    elif ("delete" in actions and "create" in actions):
        action_type = ActionType.REPLACE
    elif actions == ["no-op"] or actions == ["read"]:
        action_type = ActionType.NO_OP
    else:
        action_type = ActionType.UPDATE

    # Check billability
    if rtype in NON_BILLABLE_TYPES or rtype not in BILLABLE_TYPES:
        return ExtractedResource(
            address=address,
            resource_type=rtype,
            action=action_type,
            action_names=actions,
            is_billable=False,
            skip_reason=f"Resource type '{rtype}' is non-billable or unsupported.",
            raw_before=before,
            raw_after=after,
        )

    # For billable compute/storage resources:
    tags = after.get("tags") or before.get("tags") or {}

    # Determine OS type
    os_type = "Linux"
    if rtype == "azurerm_windows_virtual_machine":
        os_type = "Windows"
    elif rtype == "azurerm_virtual_machine":
        if "os_profile_windows_config" in after or "os_profile_windows_config" in before:
            os_type = "Windows"

    sku = None
    old_sku = None
    region = None
    old_region = None
    disk_size_gb = None
    storage_account_type = None

    if "virtual_machine" in rtype:
        # VM SKU
        if after:
            sku = after.get("size") or after.get("vm_size")
            region = normalize_region(after.get("location"))
        if before:
            old_sku = before.get("size") or before.get("vm_size")
            old_region = normalize_region(before.get("location"))

    elif rtype == "azurerm_managed_disk":
        if after:
            storage_account_type = after.get("storage_account_type") or after.get("sku") or "Premium_LRS"
            disk_size_gb = after.get("disk_size_gb") or 128
            region = normalize_region(after.get("location"))
            sku, _ = determine_disk_tier(storage_account_type, disk_size_gb)
        if before:
            b_storage = before.get("storage_account_type") or before.get("sku") or "Premium_LRS"
            b_size = before.get("disk_size_gb") or 128
            old_region = normalize_region(before.get("location"))
            old_sku, _ = determine_disk_tier(b_storage, b_size)

    return ExtractedResource(
        address=address,
        resource_type=rtype,
        action=action_type,
        action_names=actions,
        sku=sku,
        region=region or old_region or "eastus",
        old_sku=old_sku,
        old_region=old_region or region or "eastus",
        os_type=os_type,
        disk_size_gb=disk_size_gb,
        storage_account_type=storage_account_type,
        is_billable=True,
        tags=tags,
        raw_before=before,
        raw_after=after,
    )
