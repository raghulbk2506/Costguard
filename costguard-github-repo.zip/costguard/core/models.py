﻿"""Data models for CostGuard core engine."""

from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class ActionType(str, Enum):
    CREATE = "create"
    DELETE = "delete"
    UPDATE = "update"
    REPLACE = "replace"
    NO_OP = "no-op"


class PricingSource(str, Enum):
    LIVE_API = "LIVE_API"
    CACHE = "CACHED"
    FALLBACK = "FALLBACK"


class ExtractedResource(BaseModel):
    """Resource details extracted from a Terraform plan change."""
    address: str
    resource_type: str
    action: ActionType
    action_names: List[str] = Field(default_factory=list)
    sku: Optional[str] = None
    region: Optional[str] = None
    old_sku: Optional[str] = None
    old_region: Optional[str] = None
    os_type: Optional[str] = None  # Linux or Windows
    disk_size_gb: Optional[int] = None
    storage_account_type: Optional[str] = None
    is_billable: bool = True
    skip_reason: Optional[str] = None
    tags: Dict[str, str] = Field(default_factory=dict)
    raw_before: Optional[Dict[str, Any]] = None
    raw_after: Optional[Dict[str, Any]] = None


class PriceRate(BaseModel):
    """Normalized price rate for a SKU in a region."""
    sku: str
    region: str
    currency: str = "USD"
    hourly_rate: float
    monthly_rate: float
    meter_name: str = ""
    product_name: str = ""
    unit_of_measure: str = "1 Hour"
    source: PricingSource = PricingSource.LIVE_API
    cached_at: Optional[int] = None


class ResourceCostItem(BaseModel):
    """Cost breakdown item for a single resource change."""
    address: str
    resource_type: str
    action: ActionType
    region: str
    old_sku: Optional[str] = None
    new_sku: Optional[str] = None
    display_sku: str
    old_hourly: float = 0.0
    new_hourly: float = 0.0
    old_monthly: float = 0.0
    new_monthly: float = 0.0
    delta_monthly: float = 0.0
    tags: Dict[str, str] = Field(default_factory=dict)
    is_billable: bool = True
    warning: Optional[str] = None


class PolicyVerdict(BaseModel):
    """Budget guardrail evaluation verdict."""
    max_increase: float
    passed: bool
    status_text: str
    exit_code: int
    overage: float = 0.0


class PlanAnalysisResult(BaseModel):
    """Complete financial impact report for a Terraform plan."""
    items: List[ResourceCostItem] = Field(default_factory=list)
    prior_total: float = 0.0
    projected_total: float = 0.0
    net_delta: float = 0.0
    currency: str = "USD"
    verdict: PolicyVerdict
    cache_hits: int = 0
    api_calls: int = 0
    duration_ms: float = 0.0
    skipped_resources: List[Dict[str, str]] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    raw_plan_summary: Dict[str, Any] = Field(default_factory=dict)


class CacheEntry(BaseModel):
    """Single cached pricing record in SQLite."""
    sku: str
    region: str
    currency: str = "USD"
    hourly_rate: float
    cached_at: int
    meter_name: Optional[str] = None
    product_name: Optional[str] = None


class CacheStats(BaseModel):
    """Metadata and metrics of the SQLite pricing cache."""
    total_entries: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    api_calls: int = 0
    hit_rate_pct: float = 0.0
    last_updated: Optional[int] = None
