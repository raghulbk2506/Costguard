/**
 * CostGuard Backend API Client
 */

export interface ResourceCostItem {
  address: string;
  resource_type: string;
  action: 'create' | 'delete' | 'update' | 'replace' | 'no-op';
  region: string;
  old_sku: string | null;
  new_sku: string | null;
  display_sku: string;
  old_hourly: number;
  new_hourly: number;
  old_monthly: number;
  new_monthly: number;
  delta_monthly: number;
  tags: Record<string, string>;
  is_billable: boolean;
  warning: string | null;
}

export interface PolicyVerdict {
  max_increase: number;
  passed: boolean;
  status_text: string;
  exit_code: number;
  overage: number;
}

export interface PlanAnalysisResult {
  items: ResourceCostItem[];
  prior_total: number;
  projected_total: number;
  net_delta: number;
  currency: string;
  verdict: PolicyVerdict;
  cache_hits: number;
  api_calls: number;
  duration_ms: number;
  skipped_resources: Array<{ address: string; type: string; reason: string }>;
  warnings: string[];
}

export interface CacheEntry {
  sku: string;
  region: string;
  currency: string;
  hourly_rate: number;
  cached_at: number;
  meter_name: string | null;
  product_name: string | null;
}

export interface CacheStats {
  total_entries: number;
  cache_hits: number;
  cache_misses: number;
  api_calls: number;
  hit_rate_pct: number;
  last_updated: number | null;
}

export interface TestPlanInfo {
  id: string;
  filename: string;
  title: string;
  description: string;
  expected_behavior: string;
  resource_count: number;
}

const BASE_URL = '/api';

export const api = {
  async getHealth() {
    const res = await fetch(BASE_URL + '/health');
    if (!res.ok) throw new Error('API Health check failed');
    return res.json();
  },

  async analyzePlan(data: { plan_json: any; max_increase?: number; currency?: string; use_cache?: boolean }): Promise<PlanAnalysisResult> {
    const res = await fetch(BASE_URL + '/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: 'Analysis failed' }));
      throw new Error(err.detail || 'Analysis failed');
    }
    return res.json();
  },

  async analyzeUpload(file: File, max_increase = 50.0, currency = 'USD', use_cache = true): Promise<PlanAnalysisResult> {
    const formData = new FormData();
    formData.append('file', file);
    const url = BASE_URL + '/analyze/upload?max_increase=' + max_increase + '&currency=' + currency + '&use_cache=' + use_cache;
    const res = await fetch(url, {
      method: 'POST',
      body: formData,
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: 'Upload failed' }));
      throw new Error(err.detail || 'Upload failed');
    }
    return res.json();
  },

  async analyzeDemo(planName: string, max_increase = 50.0, currency = 'USD', use_cache = true): Promise<PlanAnalysisResult> {
    const url = BASE_URL + '/analyze/demo/' + planName + '?max_increase=' + max_increase + '&currency=' + currency + '&use_cache=' + use_cache;
    const res = await fetch(url, { method: 'POST' });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: 'Demo run failed' }));
      throw new Error(err.detail || 'Demo run failed');
    }
    return res.json();
  },

  async getCache(limit = 100, offset = 0, search = ''): Promise<{ stats: CacheStats; entries: CacheEntry[]; limit: number; offset: number }> {
    const params = new URLSearchParams({ limit: String(limit), offset: String(offset) });
    if (search) params.append('search', search);
    const res = await fetch(BASE_URL + '/cache?' + params.toString());
    if (!res.ok) throw new Error('Failed to fetch cache');
    return res.json();
  },

  async clearCache(): Promise<{ message: string; deleted_count: number }> {
    const res = await fetch(BASE_URL + '/cache', { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to clear cache');
    return res.json();
  },

  async getPricing(sku: string, region = 'eastus', currency = 'USD', resource_type = 'virtual_machine') {
    const params = new URLSearchParams({ sku, region, currency, resource_type });
    const res = await fetch(BASE_URL + '/pricing?' + params.toString());
    if (!res.ok) throw new Error('Pricing query failed');
    return res.json();
  },

  async getGuardrails() {
    const res = await fetch(BASE_URL + '/guardrails');
    if (!res.ok) throw new Error('Failed to load guardrails');
    return res.json();
  },

  async updateGuardrails(data: { max_increase: number; currency: string; warning_threshold_pct: number; deployment_blocking: boolean }) {
    const res = await fetch(BASE_URL + '/guardrails', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to update guardrails');
    return res.json();
  },

  async getTestPlans(): Promise<TestPlanInfo[]> {
    const res = await fetch(BASE_URL + '/test-plans');
    if (!res.ok) throw new Error('Failed to load test plans');
    return res.json();
  },

  async runTestPlan(planName: string, maxIncrease = 50.0): Promise<PlanAnalysisResult> {
    const res = await fetch(BASE_URL + '/test-plans/' + planName + '/run?max_increase=' + maxIncrease, { method: 'POST' });
    if (!res.ok) throw new Error('Failed to run test plan');
    return res.json();
  },

  async getHistory() {
    const res = await fetch(BASE_URL + '/history');
    if (!res.ok) throw new Error('Failed to fetch history');
    return res.json();
  },

  async getReport() {
    const res = await fetch(BASE_URL + '/report');
    if (!res.ok) throw new Error('Failed to fetch report');
    return res.json();
  },
};
