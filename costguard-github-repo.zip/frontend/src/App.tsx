import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Navbar } from './components/Navbar';
import { LandingPage } from './pages/LandingPage';
import { DashboardPage } from './pages/DashboardPage';
import { AnalyzePlanPage } from './pages/AnalyzePlanPage';
import { CostBreakdownPage } from './pages/CostBreakdownPage';
import { PricingExplorerPage } from './pages/PricingExplorerPage';
import { CacheManagerPage } from './pages/CacheManagerPage';
import { GuardrailsPage } from './pages/GuardrailsPage';
import { TestPlansPage } from './pages/TestPlansPage';
import { TerminalSimulator } from './components/TerminalSimulator';
import { DocsPage } from './pages/DocsPage';
import { api, PlanAnalysisResult, CacheStats } from './services/api';

export const App: React.FC = () => {
  const [currentTab, setCurrentTab] = useState<string>('landing');
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);
  const [lastResult, setLastResult] = useState<PlanAnalysisResult | null>(null);
  const [cacheStats, setCacheStats] = useState<CacheStats | undefined>(undefined);

  const refreshCacheStats = async () => {
    try {
      const data = await api.getCache(1, 0);
      setCacheStats(data.stats);
    } catch (e) {
      console.error('Failed to load cache stats', e);
    }
  };

  useEffect(() => {
    refreshCacheStats();
  }, [lastResult]);

  const handlePlanAnalyzed = (result: PlanAnalysisResult) => {
    setLastResult(result);
    refreshCacheStats();
  };

  const renderContent = () => {
    switch (currentTab) {
      case 'landing':
        return <LandingPage onNavigate={(tab) => setCurrentTab(tab)} />;
      case 'dashboard':
        return (
          <DashboardPage
            onNavigate={(tab) => setCurrentTab(tab)}
            lastResult={lastResult}
            setLastResult={handlePlanAnalyzed}
          />
        );
      case 'analyze':
        return (
          <AnalyzePlanPage
            onPlanAnalyzed={handlePlanAnalyzed}
            lastResult={lastResult}
          />
        );
      case 'breakdown':
        return <CostBreakdownPage lastResult={lastResult} />;
      case 'pricing':
        return <PricingExplorerPage />;
      case 'cache':
        return <CacheManagerPage />;
      case 'guardrails':
        return <GuardrailsPage />;
      case 'test-plans':
        return <TestPlansPage onPlanAnalyzed={handlePlanAnalyzed} />;
      case 'terminal':
        return (
          <div className="max-w-5xl mx-auto space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-white tracking-tight">Interactive Terminal Simulator</h2>
              <p className="text-xs text-slate-400">Execute CostGuard CLI directly in your browser against the live backend engine.</p>
            </div>
            <TerminalSimulator onPlanAnalyzed={handlePlanAnalyzed} />
          </div>
        );
      case 'docs':
        return <DocsPage />;
      default:
        return <LandingPage onNavigate={(tab) => setCurrentTab(tab)} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-[#0B0F17] text-slate-100 font-sans">
      {/* Sidebar Navigation */}
      <Sidebar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        isOpen={sidebarOpen}
        setIsOpen={setSidebarOpen}
        cacheStats={cacheStats}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <Navbar
          currentTab={currentTab}
          setCurrentTab={setCurrentTab}
          setSidebarOpen={setSidebarOpen}
        />
        <main className="flex-1 p-4 md:p-8 overflow-y-auto">
          {renderContent()}
        </main>
      </div>
    </div>
  );
};

export default App;