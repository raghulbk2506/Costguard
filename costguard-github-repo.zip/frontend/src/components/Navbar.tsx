import React from 'react';
import { Menu, Shield, SearchCode, Terminal, Sparkles } from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  setSidebarOpen: (open: boolean) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentTab, setCurrentTab, setSidebarOpen }) => {
  const getTitle = () => {
    switch (currentTab) {
      case 'landing': return 'Overview';
      case 'dashboard': return 'Cost Operations Dashboard';
      case 'analyze': return 'Terraform Plan Analysis';
      case 'breakdown': return 'Cost Delta Breakdown';
      case 'pricing': return 'Azure Retail Pricing Explorer';
      case 'cache': return 'SQLite Pricing Cache';
      case 'guardrails': return 'Policy Guardrails & Circuit Breaker';
      case 'test-plans': return 'Test Scenario Runner';
      case 'terminal': return 'Interactive Terminal Simulator';
      case 'docs': return 'Technical Documentation';
      default: return 'CostGuard';
    }
  };

  return (
    <header className="sticky top-0 z-30 h-16 bg-[#0B0F17]/80 backdrop-blur-md border-b border-white/10 px-4 md:px-8 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <button
          onClick={() => setSidebarOpen(true)}
          className="p-2 rounded-lg bg-white/5 border border-white/10 text-slate-300 hover:text-white md:hidden"
        >
          <Menu className="h-5 w-5" />
        </button>
        <div>
          <h1 className="text-base md:text-lg font-semibold text-white tracking-tight">{getTitle()}</h1>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <button
          onClick={() => setCurrentTab('terminal')}
          className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 border border-white/10 text-xs font-mono text-slate-300 hover:text-white transition-colors"
        >
          <Terminal className="h-3.5 w-3.5 text-blue-400" />
          costguard --help
        </button>

        <button
          onClick={() => setCurrentTab('analyze')}
          className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs md:text-sm font-medium shadow-md shadow-blue-600/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
        >
          <SearchCode className="h-4 w-4" />
          Analyze Plan
        </button>
      </div>
    </header>
  );
};