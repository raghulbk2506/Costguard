import React from 'react';
import { 
  Shield, 
  LayoutDashboard, 
  SearchCode, 
  BarChart3, 
  Coins, 
  Database, 
  Sliders, 
  FlaskConical, 
  Terminal, 
  BookOpen,
  X
} from 'lucide-react';

interface SidebarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  cacheStats?: { total_entries: number; hit_rate_pct: number };
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  setCurrentTab,
  isOpen,
  setIsOpen,
  cacheStats,
}) => {
  const navItems = [
    { id: 'landing', label: 'Overview', icon: Shield, highlight: false },
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, highlight: false },
    { id: 'analyze', label: 'Analyze Plan', icon: SearchCode, highlight: true },
    { id: 'breakdown', label: 'Cost Breakdown', icon: BarChart3, highlight: false },
    { id: 'pricing', label: 'Pricing Explorer', icon: Coins, highlight: false },
    { id: 'cache', label: 'SQLite Cache', icon: Database, highlight: false },
    { id: 'guardrails', label: 'Guardrails', icon: Sliders, highlight: false },
    { id: 'test-plans', label: 'Test Plans', icon: FlaskConical, highlight: false },
    { id: 'terminal', label: 'Terminal Simulator', icon: Terminal, highlight: false },
    { id: 'docs', label: 'Documentation', icon: BookOpen, highlight: false },
  ];

  const asideClass = 'fixed md:sticky top-0 left-0 h-screen w-64 bg-[#0B0F17] border-r border-white/10 z-50 flex flex-col justify-between transition-transform duration-300 ease-in-out ' + (isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0');

  return (
    <>
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 md:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      <aside className={asideClass}>
        <div className="p-5 border-b border-white/10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => { setCurrentTab('landing'); setIsOpen(false); }}>
              <div className="h-9 w-9 rounded-lg bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400 shadow-lg shadow-blue-500/10">
                <Shield className="h-5 w-5 text-blue-400" />
              </div>
              <div>
                <span className="font-bold text-lg tracking-tight text-white flex items-center gap-1.5">
                  CostGuard
                  <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30">v1.0</span>
                </span>
                <p className="text-[11px] text-slate-400 font-mono">Infra Cost Firewall</p>
              </div>
            </div>
            <button 
              className="p-1 rounded md:hidden text-slate-400 hover:text-white"
              onClick={() => setIsOpen(false)}
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          <div className="px-3 pb-2 text-[10px] font-mono uppercase tracking-wider text-slate-400">Navigation</div>
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = currentTab === item.id;
            const btnClass = 'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all text-left ' + (
              active 
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20' 
                : item.highlight
                ? 'text-blue-400 hover:bg-blue-500/10'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
            );
            const iconClass = 'h-4 w-4 ' + (active ? 'text-white' : item.highlight ? 'text-blue-400' : 'text-slate-400');

            return (
              <button
                key={item.id}
                onClick={() => {
                  setCurrentTab(item.id);
                  setIsOpen(false);
                }}
                className={btnClass}
              >
                <Icon className={iconClass} />
                <span className="flex-1">{item.label}</span>
                {item.highlight && !active && (
                  <span className="h-1.5 w-1.5 rounded-full bg-blue-400" />
                )}
              </button>
            );
          })}
        </div>

        <div className="p-4 border-t border-white/10 bg-[#0E1522]/50">
          <div className="rounded-lg p-3 bg-white/5 border border-white/5 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400 flex items-center gap-1.5">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                Azure Retail API
              </span>
              <span className="text-[10px] font-mono text-emerald-400">Live</span>
            </div>
            <div className="flex items-center justify-between text-xs pt-1 border-t border-white/5">
              <span className="text-slate-400 flex items-center gap-1.5">
                <Database className="h-3 w-3 text-blue-400" />
                SQLite Cache
              </span>
              <span className="text-[10px] font-mono text-slate-300">
                {String(cacheStats?.total_entries ?? 0) + ' keys (' + String(cacheStats?.hit_rate_pct ?? 0) + '%)'}
              </span>
            </div>
          </div>
          <div className="mt-3 text-[11px] text-center text-slate-400 font-mono">
            730 hrs/mo normalization
          </div>
        </div>
      </aside>
    </>
  );
};
