import React from 'react';
import { LucideIcon } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string;
  delta?: string;
  isPositiveDelta?: boolean;
  subtitle?: string;
  icon: LucideIcon;
  badge?: string;
  badgeColor?: 'blue' | 'green' | 'red' | 'yellow';
}

export const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  delta,
  isPositiveDelta,
  subtitle,
  icon: Icon,
  badge,
  badgeColor = 'blue',
}) => {
  const getBadgeStyle = () => {
    switch (badgeColor) {
      case 'green': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
      case 'red': return 'bg-rose-500/10 text-rose-400 border-rose-500/20';
      case 'yellow': return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
      default: return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
    }
  };

  const deltaStyle = isPositiveDelta 
    ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' 
    : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20';

  return (
    <div className="rounded-xl bg-[#111827]/80 border border-white/10 p-5 shadow-lg relative overflow-hidden backdrop-blur-sm hover:border-white/20 transition-all">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">{title}</p>
          <h3 className="text-2xl font-bold text-white mt-1 font-mono tracking-tight">{value}</h3>
        </div>
        <div className="h-10 w-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-blue-400">
          <Icon className="h-5 w-5" />
        </div>
      </div>

      <div className="mt-3 flex items-center gap-2">
        {delta && (
          <span className={'text-xs font-mono font-medium px-2 py-0.5 rounded ' + deltaStyle}>
            {delta}
          </span>
        )}
        {badge && (
          <span className={'text-[10px] font-mono px-2 py-0.5 rounded border ' + getBadgeStyle()}>
            {badge}
          </span>
        )}
        {subtitle && (
          <span className="text-xs text-slate-400">{subtitle}</span>
        )}
      </div>
    </div>
  );
};
