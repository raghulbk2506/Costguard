import React, { useState, useEffect } from 'react';
import { Terminal as TerminalIcon, Play, Copy, Check, RotateCcw } from 'lucide-react';
import { api, PlanAnalysisResult } from '../services/api';

interface TerminalSimulatorProps {
  onPlanAnalyzed?: (result: PlanAnalysisResult) => void;
}

export const TerminalSimulator: React.FC<TerminalSimulatorProps> = ({ onPlanAnalyzed }) => {
  const [selectedCommand, setSelectedCommand] = useState('plan_b_50');
  const [customInput, setCustomInput] = useState('terraform show -json tfplan.binary | costguard --max-increase 50');
  const [running, setRunning] = useState(false);
  const [outputLines, setOutputLines] = useState<Array<{ text: string; color?: string; style?: string }>>([]);
  const [exitCode, setExitCode] = useState<number | null>(null);
  const [copied, setCopied] = useState(false);

  const presets = [
    {
      id: 'plan_b_50',
      label: 'Standard Pipe: Plan B ($50 Budget)',
      cmd: 'terraform show -json tfplan.binary | costguard --max-increase 50',
      plan: 'plan_b',
      maxIncrease: 50,
    },
    {
      id: 'plan_b_20',
      label: 'Circuit Breaker Fail: Plan B ($20 Budget)',
      cmd: 'costguard --plan ./test-plans/plan_b_upgrade_delete.json --max-increase 20',
      plan: 'plan_b',
      maxIncrease: 20,
    },
    {
      id: 'plan_a_50',
      label: 'Plan A: The Small Add ($50 Budget)',
      cmd: 'costguard --plan ./test-plans/plan_a_small_add.json --max-increase 50',
      plan: 'plan_a',
      maxIncrease: 50,
    },
    {
      id: 'plan_c_noise',
      label: 'Plan C: Hostile Noise (15 Non-Billable)',
      cmd: 'cat test-plans/plan_c_hostile_noise.json | costguard',
      plan: 'plan_c',
      maxIncrease: 50,
    },
    {
      id: 'plan_d_meta',
      label: 'Plan D: Metadata-Only ($0.00 Delta)',
      cmd: 'costguard --plan ./test-plans/plan_d_metadata_only.json',
      plan: 'plan_d',
      maxIncrease: 50,
    },
  ];

  const handleSelectPreset = (presetId: string) => {
    setSelectedCommand(presetId);
    const p = presets.find((x) => x.id === presetId);
    if (p) {
      setCustomInput(p.cmd);
    }
  };

  const runCommand = async () => {
    setRunning(true);
    setExitCode(null);
    setOutputLines([
      { text: '$ ' + customInput, color: 'text-slate-300', style: 'font-bold' },
      { text: '[SYSTEM] Initializing CostGuard v1.0.0 engine...', color: 'text-slate-400' },
    ]);

    try {
      let planName = 'plan_b';
      let maxIncrease = 50.0;

      if (customInput.includes('plan_a')) planName = 'plan_a';
      else if (customInput.includes('plan_c')) planName = 'plan_c';
      else if (customInput.includes('plan_d')) planName = 'plan_d';

      const matchMax = customInput.match(/--max-increase\s+(\d+(\.\d+)?)/);
      if (matchMax) {
        maxIncrease = parseFloat(matchMax[1]);
      }

      setOutputLines((prev) => [
        ...prev,
        { text: '[INFO] Parsing Terraform compiled plan stream...', color: 'text-cyan-400' },
        { text: '[INFO] Checking local SQLite pricing_cache.db...', color: 'text-blue-400' },
        { text: '[INFO] Querying Azure Retail Prices REST API (prices.azure.com)...', color: 'text-blue-400' },
      ]);

      const result: PlanAnalysisResult = await api.analyzeDemo(planName, maxIncrease);

      if (onPlanAnalyzed) onPlanAnalyzed(result);

      const newLines: Array<{ text: string; color?: string; style?: string }> = [];
      if (result.skipped_resources.length > 0) {
        result.skipped_resources.forEach((sk) => {
          newLines.push({ text: '[INFO] Skipping non-billable resource: ' + sk.address, color: 'text-slate-400' });
        });
      }

      newLines.push({ text: '='.repeat(88), color: 'text-cyan-500' });
      newLines.push({ text: 'COSTGUARD: Azure Infrastructure Cost Impact Report', color: 'text-white font-bold bg-blue-900/40' });
      newLines.push({ text: '='.repeat(88), color: 'text-cyan-500' });

      newLines.push({
        text: 'Resource Address                   Action  Region   SKU / Meter               Old ($/mo)  New ($/mo)  Delta ($/mo)',
        color: 'text-slate-200 font-bold',
      });
      newLines.push({ text: '-'.repeat(88), color: 'text-slate-700' });

      result.items.forEach((it) => {
        const act = it.action.toUpperCase().padEnd(7);
        const addr = (it.address.length > 34 ? it.address.substring(0, 31) + '...' : it.address).padEnd(35);
        const reg = it.region.padEnd(8);
        const sku = (it.display_sku.length > 25 ? it.display_sku.substring(0, 22) + '...' : it.display_sku).padEnd(26);
        const oldC = ('$' + it.old_monthly.toFixed(2)).padStart(10);
        const newC = ('$' + it.new_monthly.toFixed(2)).padStart(11);
        const sign = it.delta_monthly >= 0 ? '+' : '-';
        const deltaC = (sign + '$' + Math.abs(it.delta_monthly).toFixed(2)).padStart(12);

        let deltaColor = 'text-white';
        if (it.delta_monthly > 0) deltaColor = 'text-rose-400 font-semibold';
        else if (it.delta_monthly < 0) deltaColor = 'text-emerald-400 font-semibold';

        newLines.push({
          text: addr + ' ' + act + ' ' + reg + ' ' + sku + ' ' + oldC + ' ' + newC + ' ' + deltaC,
          color: deltaColor,
        });
      });

      newLines.push({ text: '-'.repeat(88), color: 'text-cyan-500' });
      newLines.push({ text: 'FINANCIAL SUMMARY:', color: 'text-white font-bold' });
      newLines.push({ text: '  Prior Monthly Total:     $' + result.prior_total.toFixed(2) + '/mo', color: 'text-slate-300' });
      newLines.push({ text: '  Projected Monthly Total: $' + result.projected_total.toFixed(2) + '/mo', color: 'text-slate-300' });
      
      const hitsWord = result.cache_hits === 1 ? 'hit' : 'hits';
      const lookupsWord = result.api_calls === 1 ? 'lookup' : 'lookups';
      const netSign = result.net_delta >= 0 ? '+' : '-';
      const deltaColor = result.net_delta <= 0 ? 'text-emerald-400' : 'text-rose-400';

      newLines.push({
        text: '  Net Monthly Impact:      ' + netSign + '$' + Math.abs(result.net_delta).toFixed(2) + '/mo  [Cache: ' + result.cache_hits + ' ' + hitsWord + ', ' + result.api_calls + ' API ' + lookupsWord + ']',
        color: deltaColor + ' font-bold',
      });

      newLines.push({ text: '-'.repeat(88), color: 'text-cyan-500' });
      newLines.push({ text: 'POLICY VERDICT:', color: 'text-white font-bold' });
      newLines.push({ text: '  Budget Threshold:        +$' + result.verdict.max_increase.toFixed(2) + '/mo', color: 'text-slate-300' });

      if (result.verdict.passed) {
        newLines.push({ text: '  Status:                  PASSED (Within budget allowance)', color: 'text-emerald-400 font-bold' });
        newLines.push({ text: '='.repeat(88), color: 'text-cyan-500' });
        newLines.push({ text: 'Process exited with status code 0', color: 'text-emerald-500 font-mono text-xs' });
        setExitCode(0);
      } else {
        newLines.push({
          text: '  Status:                  FAILED (Exceeds budget allowance by +$' + result.verdict.overage.toFixed(2) + '/mo)',
          color: 'text-rose-400 font-bold',
        });
        newLines.push({
          text: '[CIRCUIT BREAKER] CostGuard: Budget threshold breached. Deployment blocked.',
          color: 'text-rose-500 font-bold',
        });
        newLines.push({ text: '='.repeat(88), color: 'text-rose-500' });
        newLines.push({ text: 'Process exited with status code 1', color: 'text-rose-500 font-mono text-xs' });
        setExitCode(1);
      }

      setOutputLines((prev) => [...prev, ...newLines]);
    } catch (err: any) {
      setOutputLines((prev) => [
        ...prev,
        { text: 'Error: ' + (err.message || 'Execution error'), color: 'text-rose-400 font-bold' },
        { text: 'Process exited with status code 2', color: 'text-rose-500 font-mono text-xs' },
      ]);
      setExitCode(2);
    } finally {
      setRunning(false);
    }
  };

  useEffect(() => {
    runCommand();
  }, []);

  const handleCopy = () => {
    const raw = outputLines.map((l) => l.text).join('\n');
    navigator.clipboard.writeText(raw);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="rounded-xl bg-[#0D1117] border border-white/10 shadow-2xl overflow-hidden font-mono">
      <div className="bg-[#161B22] px-4 py-3 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex gap-1.5">
            <div className="h-3 w-3 rounded-full bg-rose-500/80" />
            <div className="h-3 w-3 rounded-full bg-amber-500/80" />
            <div className="h-3 w-3 rounded-full bg-emerald-500/80" />
          </div>
          <span className="text-xs text-slate-400 ml-2 font-mono flex items-center gap-1.5">
            <TerminalIcon className="h-3.5 w-3.5 text-blue-400" />
            costguard-cli -- bash
          </span>
        </div>

        <div className="flex items-center gap-2">
          {exitCode !== null && (
            <span className={'text-[11px] px-2 py-0.5 rounded font-mono border ' + (
              exitCode === 0 
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' 
                : 'bg-rose-500/10 text-rose-400 border-rose-500/20'
            )}>
              exit {exitCode}
            </span>
          )}
          <button
            onClick={handleCopy}
            className="p-1 rounded bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
            title="Copy Terminal Output"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
          </button>
        </div>
      </div>

      <div className="bg-[#111620] px-4 py-2 border-b border-white/5 flex flex-wrap items-center gap-2 text-xs">
        <span className="text-slate-400 text-[11px] font-sans">Quick Scenarios:</span>
        {presets.map((p) => (
          <button
            key={p.id}
            onClick={() => handleSelectPreset(p.id)}
            className={'px-2.5 py-1 rounded text-[11px] transition-all ' + (
              selectedCommand === p.id
                ? 'bg-blue-600 text-white font-medium'
                : 'bg-white/5 text-slate-400 hover:text-slate-200 hover:bg-white/10'
            )}
          >
            {p.label}
          </button>
        ))}
      </div>

      <div className="p-3 bg-[#0B0F17] border-b border-white/10 flex items-center gap-2">
        <span className="text-emerald-400 font-bold">$</span>
        <input
          type="text"
          value={customInput}
          onChange={(e) => setCustomInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && runCommand()}
          placeholder="costguard --plan test-plans/plan_b_upgrade_delete.json"
          className="flex-1 bg-transparent text-slate-100 text-xs md:text-sm focus:outline-none font-mono"
        />
        <button
          onClick={runCommand}
          disabled={running}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-sans font-medium transition-all shadow-md shadow-blue-600/20"
        >
          {running ? (
            <>
              <RotateCcw className="h-3.5 w-3.5 animate-spin" />
              Running...
            </>
          ) : (
            <>
              <Play className="h-3.5 w-3.5" />
              Run CostGuard
            </>
          )}
        </button>
      </div>

      <div className="p-4 overflow-x-auto max-h-[460px] overflow-y-auto space-y-1 text-xs md:text-[13px] leading-relaxed select-text">
        {outputLines.map((line, idx) => (
          <div key={idx} className={(line.color || 'text-slate-300') + ' ' + (line.style || '') + ' whitespace-pre'}>
            {line.text}
          </div>
        ))}
      </div>
    </div>
  );
};
