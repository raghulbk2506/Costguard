import React, { useState, useEffect } from 'react';
import { Trash2, RefreshCw, CheckCircle2, Search, AlertCircle } from 'lucide-react';
import { api, CacheEntry, CacheStats } from '../services/api';

export const CacheManagerPage: React.FC = () => {
  const [stats, setStats] = useState<CacheStats | null>(null);
  const [entries, setEntries] = useState<CacheEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [clearing, setClearing] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const fetchCache = async () => {
    setLoading(true);
    try {
      const data = await api.getCache(100, 0, search);
      setStats(data.stats);
      setEntries(data.entries);
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCache();
  }, [search]);

  const handleClearCache = async () => {
    setClearing(true);
    try {
      const res = await api.clearCache();
      setMessage(`Successfully purged ${res.deleted_count} cache entries from SQLite.`);
      setShowClearConfirm(false);
      await fetchCache();
    } catch (err: any) {
      console.error(err);
    } finally {
      setClearing(false);
    }
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">SQLite Write-Through Cache</h2>
          <p className="text-xs text-slate-400">Local embedded pricing cache (<code className="text-xs text-blue-300">pricing_cache.db</code>) eliminating redundant Azure API lookups.</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => fetchCache()}
            disabled={loading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-slate-300 font-mono transition-all"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
          <button
            onClick={() => setShowClearConfirm(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 text-xs text-rose-400 font-mono transition-all"
          >
            <Trash2 className="h-3.5 w-3.5" />
            Clear Cache
          </button>
        </div>
      </div>

      {message && (
        <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs flex items-center gap-2">
          <CheckCircle2 className="h-4 w-4" />
          <span>{message}</span>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-[#111827]/80 border border-white/10">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Cached Records</span>
          <h3 className="text-2xl font-bold font-mono text-white mt-1">{stats?.total_entries ?? 0}</h3>
          <span className="text-xs text-slate-400">Unique (SKU, Region, Currency)</span>
        </div>

        <div className="p-4 rounded-xl bg-[#111827]/80 border border-white/10">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Cache Hit Rate</span>
          <h3 className="text-2xl font-bold font-mono text-emerald-400 mt-1">{stats?.hit_rate_pct ?? 0}%</h3>
          <span className="text-xs text-slate-400">{stats?.cache_hits ?? 0} hits recorded</span>
        </div>

        <div className="p-4 rounded-xl bg-[#111827]/80 border border-white/10">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Live API Calls Saved</span>
          <h3 className="text-2xl font-bold font-mono text-blue-400 mt-1">{stats?.cache_hits ?? 0}</h3>
          <span className="text-xs text-slate-400">{stats?.api_calls ?? 0} network requests made</span>
        </div>

        <div className="p-4 rounded-xl bg-[#111827]/80 border border-white/10">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Storage Engine</span>
          <h3 className="text-2xl font-bold font-mono text-white mt-1">SQLite3</h3>
          <span className="text-xs text-slate-400">pricing_cache.db</span>
        </div>
      </div>

      <div className="rounded-xl bg-[#111827]/80 border border-white/10 overflow-hidden">
        <div className="p-4 border-b border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative w-full sm:w-72">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search cached SKU or region..."
              className="w-full bg-[#0D1117] border border-white/10 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-blue-500"
            />
            <Search className="h-3.5 w-3.5 text-slate-400 absolute left-3 top-2.5" />
          </div>
          <span className="text-xs text-slate-400 font-mono">
            Showing {entries.length} cached keys
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-white/5 text-slate-400 uppercase font-mono">
              <tr>
                <th className="px-6 py-3">SKU</th>
                <th className="px-6 py-3">Region</th>
                <th className="px-6 py-3">Currency</th>
                <th className="px-6 py-3 text-right">Hourly Rate</th>
                <th className="px-6 py-3 text-right">Monthly (730h)</th>
                <th className="px-6 py-3 text-right">Cached At</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-slate-300">
              {entries.length > 0 ? (
                entries.map((e, idx) => (
                  <tr key={idx} className="hover:bg-white/5 transition-colors">
                    <td className="px-6 py-3.5 font-mono text-cyan-300 font-semibold">{e.sku}</td>
                    <td className="px-6 py-3.5 font-mono text-slate-300 uppercase">{e.region}</td>
                    <td className="px-6 py-3.5 font-mono">{e.currency}</td>
                    <td className="px-6 py-3.5 text-right font-mono">${e.hourly_rate.toFixed(4)}</td>
                    <td className="px-6 py-3.5 text-right font-mono text-emerald-400 font-bold">
                      ${(e.hourly_rate * 730).toFixed(2)}
                    </td>
                    <td className="px-6 py-3.5 text-right font-mono text-slate-400">
                      {new Date(e.cached_at * 1000).toLocaleString()}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-slate-400 font-mono">
                    No matching cached pricing entries found in SQLite.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showClearConfirm && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#111827] border border-white/10 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center gap-3 text-rose-400">
              <AlertCircle className="h-6 w-6" />
              <h3 className="text-lg font-bold text-white tracking-tight">Purge SQLite Cache?</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              This will delete all stored pricing records in <code className="text-white">pricing_cache.db</code>. 
              The next plan analysis will query the live Azure Retail API again for all resource SKUs.
            </p>
            <div className="flex items-center justify-end gap-3 pt-3">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="px-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-slate-300 font-mono transition-all"
              >
                Cancel
              </button>
              <button
                onClick={handleClearCache}
                disabled={clearing}
                className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-xs text-white font-mono font-bold transition-all"
              >
                {clearing ? 'Purging...' : 'Yes, Purge Cache'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
