import React from 'react';
import { Terminal, Shield, Cpu, Sliders } from 'lucide-react';

export const DocsPage: React.FC = () => {
  return (
    <div className="space-y-12 max-w-4xl mx-auto pb-16 text-slate-300">
      <div>
        <h2 className="text-3xl font-extrabold text-white tracking-tight">Technical Documentation</h2>
        <p className="text-sm text-slate-400 mt-1">Architecture, CLI integration, Azure pricing rules, and CI/CD pipelines.</p>
      </div>

      <section className="space-y-4">
        <h3 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
          <Shield className="h-5 w-5 text-blue-400" />
          1. System Architecture
        </h3>
        <p className="text-sm leading-relaxed">
          CostGuard is a shift-left FinOps firewall designed to evaluate the monthly infrastructure cost impact of Terraform plans before any cloud resources are created, modified, or destroyed.
        </p>

        <pre className="p-4 rounded-xl bg-[#0D1117] border border-white/10 font-mono text-xs text-cyan-300 overflow-x-auto leading-relaxed">
{`[Terraform Plan JSON] ---> (stdin / --plan flag)
        |
        v
+--------------------------------------------------------------+
| 1. RESOURCE EXTRACTOR                                        |
| Parses resource_changes[]:                                   |
| - Filters for billable types (VM, Managed Disk)              |
| - Detects actions: create / delete / update / replace        |
| - Extracts SKU name, size, and normalized Azure region       |
+--------------------------------------------------------------+
        |
        v
+--------------------------------------------------------------+
| 2. TIERED PRICING ENGINE (Cache + Azure API)                 |
| For each unique (SKU, Region, Currency):                     |
| - Step 2A: Query local SQLite pricing_cache.db               |
| - Step 2B: Cache miss? Query live Azure Retail Prices API    |
| - Step 2C: Filter out Spot & Low Priority meters             |
| - Step 2D: Write-through cache rate in SQLite                |
| - Step 2E: Monthly Cost = Hourly Rate x 730 hours            |
+--------------------------------------------------------------+
        |
        v
+--------------------------------------------------------------+
| 3. POLICY GUARDRAIL & CIRCUIT BREAKER                        |
| - Net Delta = Total Proposed - Total Prior                   |
| - Evaluates Delta against --max-increase                     |
| - Exits 0 (Within budget) or 1 (Breached / Blocked)          |
+--------------------------------------------------------------+`}
        </pre>
      </section>

      <section className="space-y-4">
        <h3 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
          <Terminal className="h-5 w-5 text-blue-400" />
          2. CLI Invocation Syntax
        </h3>
        <p className="text-sm leading-relaxed">
          The <code className="text-blue-300">costguard</code> CLI supports both standard UNIX piping and explicit file flags:
        </p>

        <div className="space-y-3 font-mono text-xs">
          <div className="p-3 rounded-lg bg-[#0D1117] border border-white/10">
            <span className="text-slate-400 block mb-1"># 1. Pipe compiled plan directly from Terraform:</span>
            <code className="text-emerald-400">terraform show -json tfplan.binary | costguard --max-increase 50</code>
          </div>

          <div className="p-3 rounded-lg bg-[#0D1117] border border-white/10">
            <span className="text-slate-400 block mb-1"># 2. Analyze explicit JSON plan file:</span>
            <code className="text-emerald-400">costguard --plan ./test-plans/upgrade.json --max-increase 25 --currency EUR</code>
          </div>

          <div className="p-3 rounded-lg bg-[#0D1117] border border-white/10">
            <span className="text-slate-400 block mb-1"># 3. Output GitHub PR Markdown table comment:</span>
            <code className="text-emerald-400">costguard --plan ./test-plans/plan_b_upgrade_delete.json --markdown</code>
          </div>

          <div className="p-3 rounded-lg bg-[#0D1117] border border-white/10">
            <span className="text-slate-400 block mb-1"># 4. Clear cache and force live network lookups:</span>
            <code className="text-emerald-400">costguard --clear-cache --plan plan.json</code>
          </div>
        </div>
      </section>

      <section className="space-y-4">
        <h3 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
          <Sliders className="h-5 w-5 text-blue-400" />
          3. Process Exit Codes Contract
        </h3>
        <p className="text-sm leading-relaxed">
          CostGuard operates as an automated CI/CD pipeline gatekeeper with strict POSIX exit codes:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/20 space-y-1">
            <span className="font-mono font-bold text-emerald-400">Exit Code 0</span>
            <h4 className="text-white font-semibold text-xs">Within Budget</h4>
            <p className="text-[11px] text-slate-400">Net monthly delta is less than or equal to <code className="text-emerald-300">--max-increase</code>.</p>
          </div>

          <div className="p-4 rounded-xl bg-rose-950/20 border border-rose-500/20 space-y-1">
            <span className="font-mono font-bold text-rose-400">Exit Code 1</span>
            <h4 className="text-white font-semibold text-xs">Policy Breached</h4>
            <p className="text-[11px] text-slate-400">Cost exceeds budget ceiling. CI/CD deployment pipeline terminates immediately.</p>
          </div>

          <div className="p-4 rounded-xl bg-amber-950/20 border border-amber-500/20 space-y-1">
            <span className="font-mono font-bold text-amber-400">Exit Code 2</span>
            <h4 className="text-white font-semibold text-xs">Input Error</h4>
            <p className="text-[11px] text-slate-400">Invalid JSON input, missing plan file, or illegal argument flags.</p>
          </div>
        </div>
      </section>

      <section className="space-y-4">
        <h3 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
          <Cpu className="h-5 w-5 text-blue-400" />
          4. Azure Retail Prices API Contract
        </h3>
        <ul className="list-disc list-inside space-y-2 text-sm text-slate-300">
          <li><strong>Base Endpoint:</strong> <code className="text-xs text-blue-300">https://prices.azure.com/api/retail/prices</code> (Unauthenticated public REST endpoint).</li>
          <li><strong>Non-Spot Filtering Rule:</strong> Must query with <code className="text-xs text-blue-300">priceType eq 'Consumption'</code> and reject meters containing <code className="text-xs text-rose-300">Spot</code> or <code className="text-xs text-rose-300">Low Priority</code>.</li>
          <li><strong>730 Hours Baseline:</strong> Monthly cost is normalized using <code className="text-xs text-emerald-300">monthly_cost = hourly_rate * 730</code> (standard operational baseline).</li>
          <li><strong>Graceful Skip Rule:</strong> Non-billable resources (<code className="text-xs text-slate-400">azurerm_resource_group</code>, <code className="text-xs text-slate-400">azurerm_subnet</code>, <code className="text-xs text-slate-400">azurerm_virtual_network</code>) are skipped cleanly without crashing.</li>
        </ul>
      </section>

      <section className="space-y-4">
        <h3 className="text-xl font-bold text-white tracking-tight">5. GitHub Actions CI/CD Pipeline</h3>
        <pre className="p-4 rounded-xl bg-[#0D1117] border border-white/10 font-mono text-xs text-slate-300 overflow-x-auto leading-relaxed">
{`name: Terraform Cost Guardrail
on: [pull_request]

jobs:
  costguard:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: hashicorp/setup-terraform@v3

      - name: Terraform Plan
        run: |
          terraform init
          terraform plan -out=tfplan.binary
          terraform show -json tfplan.binary > tfplan.json

      - name: Run CostGuard
        run: |
          pip install costguard
          costguard --plan tfplan.json --max-increase 50 --markdown`}
        </pre>
      </section>
    </div>
  );
};
