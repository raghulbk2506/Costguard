import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell
} from 'recharts';
import { TrendingUp, DollarSign } from 'lucide-react';
import { PlanAnalysisResult } from '../services/api';

interface CostBreakdownPageProps {
  lastResult: PlanAnalysisResult | null;
}

export const CostBreakdownPage: React.FC<CostBreakdownPageProps> = ({ lastResult }) => {
  const result = lastResult || {
    prior_total: 15.18,
    projected_total: 50.08,
    net_delta: 34.90,
    currency: 'USD',
    items: [
      {
        address: 'azurerm_linux_virtual_machine.app',
        resource_type: 'azurerm_linux_virtual_machine',
        action: 'update' as const,
        region: 'eastus',
        old_sku: 'Standard_B1s',
        new_sku: 'Standard_B2s',
        display_sku: 'Standard_B1s -> Standard_B2s',
        old_hourly: 0.0104,
        new_hourly: 0.0416,
        old_monthly: 7.59,
        new_monthly: 30.37,
        delta_monthly: 22.78,
        tags: {},
        is_billable: true,
        warning: null,
      },
      {
        address: 'azurerm_managed_disk.data',
        resource_type: 'azurerm_managed_disk',
        action: 'create' as const,
        region: 'eastus',
        old_sku: null,
        new_sku: 'Premium_SSD_Managed_Disk_P10',
        display_sku: 'P10 Premium SSD (128GB)',
        old_hourly: 0.0,
        new_hourly: 0.0270,
        old_monthly: 0.0,
        new_monthly: 19.71,
        delta_monthly: 19.71,
        tags: {},
        is_billable: true,
        warning: null,
      },
      {
        address: 'azurerm_linux_virtual_machine.old',
        resource_type: 'azurerm_linux_virtual_machine',
        action: 'delete' as const,
        region: 'eastus',
        old_sku: 'Standard_B1s',
        new_sku: null,
        display_sku: 'Standard_B1s',
        old_hourly: 0.0104,
        new_hourly: 0.0,
        old_monthly: 7.59,
        new_monthly: 0.0,
        delta_monthly: -7.59,
        tags: {},
        is_billable: true,
        warning: null,
      },
    ],
    verdict: { max_increase: 50.0, passed: true, status_text: 'PASSED', exit_code: 0, overage: 0 },
    cache_hits: 4,
    api_calls: 0,
    duration_ms: 12.0,
    skipped_resources: [],
    warnings: [],
  };

  const totalsData = [
    { name: 'Prior Total', amount: result.prior_total, fill: '#64748B' },
    { name: 'Projected Total', amount: result.projected_total, fill: '#3B82F6' },
  ];

  const deltaData = result.items.map((it) => ({
    name: it.address.split('.').pop() || it.address,
    delta: it.delta_monthly,
    old: it.old_monthly,
    new: it.new_monthly,
    action: it.action.toUpperCase(),
  }));

  return (
    <div className="space-y-8 max-w-6xl mx-auto pb-12">
      <div>
        <h2 className="text-2xl font-bold text-white tracking-tight">Cost Breakdown & Visualizations</h2>
        <p className="text-xs text-slate-400">Detailed financial analysis of infrastructure changes.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-[#111827]/80 border border-white/10">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Prior Monthly Run-Rate</span>
          <h3 className="text-2xl font-bold font-mono text-white mt-1">${result.prior_total.toFixed(2)}</h3>
          <span className="text-xs text-slate-400">Baseline across billable resources</span>
        </div>

        <div className="p-4 rounded-xl bg-[#111827]/80 border border-white/10">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Projected Monthly Total</span>
          <h3 className="text-2xl font-bold font-mono text-white mt-1">${result.projected_total.toFixed(2)}</h3>
          <span className="text-xs text-slate-400">730 operational hours baseline</span>
        </div>

        <div className="p-4 rounded-xl bg-[#111827]/80 border border-white/10">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Net Monthly Delta</span>
          <h3 className={`text-2xl font-bold font-mono mt-1 ${result.net_delta > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
            {result.net_delta >= 0 ? '+' : '-'}${Math.abs(result.net_delta).toFixed(2)}
          </h3>
          <span className="text-xs text-slate-400">Financial threshold delta</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-xl bg-[#111827]/80 border border-white/10 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-white tracking-tight">Prior vs Projected Monthly Cost</h3>
              <p className="text-xs text-slate-400">Overall infrastructure bill shift</p>
            </div>
            <DollarSign className="h-4 w-4 text-blue-400" />
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={totalsData} margin={{ top: 20, right: 20, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" vertical={false} />
                <XAxis dataKey="name" stroke="#94A3B8" fontSize={12} tickLine={false} />
                <YAxis stroke="#94A3B8" fontSize={12} tickFormatter={(v) => `$${v}`} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0F172A', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(val: any) => [`$${Number(val).toFixed(2)}/mo`, 'Cost']}
                />
                <Bar dataKey="amount" radius={[6, 6, 0, 0]}>
                  {totalsData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-xl bg-[#111827]/80 border border-white/10 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-white tracking-tight">Resource Delta Contribution</h3>
              <p className="text-xs text-slate-400">Individual impact: positive increases vs deletions</p>
            </div>
            <TrendingUp className="h-4 w-4 text-blue-400" />
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={deltaData} margin={{ top: 20, right: 20, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" vertical={false} />
                <XAxis dataKey="name" stroke="#94A3B8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94A3B8" fontSize={12} tickFormatter={(v) => `$${v}`} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0F172A', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(val: any) => [`${val >= 0 ? '+' : '-'}$${Math.abs(Number(val)).toFixed(2)}/mo`, 'Net Delta']}
                />
                <Bar dataKey="delta" radius={[6, 6, 0, 0]}>
                  {deltaData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.delta > 0 ? '#EF4444' : entry.delta < 0 ? '#10B981' : '#64748B'} 
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="rounded-xl bg-[#111827]/80 border border-white/10 overflow-hidden">
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white tracking-tight">Resource Attribution Matrix</h3>
          <span className="text-xs text-slate-400 font-mono">Formula: Delta = New - Old</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-white/5 text-slate-400 uppercase font-mono">
              <tr>
                <th className="px-6 py-3">Resource</th>
                <th className="px-6 py-3">Action</th>
                <th className="px-6 py-3">SKU / Meter</th>
                <th className="px-6 py-3 text-right">Prior Rate</th>
                <th className="px-6 py-3 text-right">New Rate</th>
                <th className="px-6 py-3 text-right">Monthly Delta</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-slate-300">
              {result.items.map((it, idx) => (
                <tr key={idx} className="hover:bg-white/5 transition-colors">
                  <td className="px-6 py-3.5 font-mono text-cyan-300 font-medium">
                    {it.address}
                  </td>
                  <td className="px-6 py-3.5 font-mono">
                    <span className="px-2 py-0.5 rounded text-[10px] bg-white/5 border border-white/10 uppercase">
                      {it.action}
                    </span>
                  </td>
                  <td className="px-6 py-3.5 font-mono text-slate-200">
                    {it.display_sku}
                  </td>
                  <td className="px-6 py-3.5 text-right font-mono text-slate-400">
                    ${it.old_monthly.toFixed(2)}
                  </td>
                  <td className="px-6 py-3.5 text-right font-mono text-slate-200">
                    ${it.new_monthly.toFixed(2)}
                  </td>
                  <td className="px-6 py-3.5 text-right font-mono font-bold">
                    <span className={it.delta_monthly > 0 ? 'text-rose-400' : it.delta_monthly < 0 ? 'text-emerald-400' : 'text-slate-400'}>
                      {it.delta_monthly >= 0 ? '+' : '-'}${Math.abs(it.delta_monthly).toFixed(2)}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
