import React from 'react';
import { 
  Shield, 
  ArrowRight, 
  Cpu, 
  Database, 
  Sliders, 
  FileCode2, 
  CheckCircle2, 
  Zap, 
  AlertTriangle,
  Server
} from 'lucide-react';
import { TerminalSimulator } from '../components/TerminalSimulator';

interface LandingPageProps {
  onNavigate: (tab: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  return (
    <div className="space-y-16 pb-12 max-w-6xl mx-auto">
      {/* Hero Section */}
      <section className="text-center pt-8 md:pt-14 space-y-6">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-mono">
          <Zap className="h-3.5 w-3.5" />
          Shift-Left FinOps for Terraform
        </div>

        <h1 className="text-3xl md:text-5xl lg:text-6xl font-extrabold tracking-tight text-white max-w-4xl mx-auto leading-tight">
          CATCH CLOUD COST INCREASES <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-sky-300 to-indigo-400">
            BEFORE THEY REACH PRODUCTION.
          </span>
        </h1>

        <p className="text-slate-400 text-base md:text-lg max-w-2xl mx-auto leading-relaxed">
          Analyze Terraform plans, retrieve live Azure pricing, calculate monthly infrastructure impact (730 hrs), 
          and block changes that exceed your team budget.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
          <button
            onClick={() => onNavigate('analyze')}
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-medium text-sm shadow-xl shadow-blue-600/25 transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            Analyze Terraform Plan
            <ArrowRight className="h-4 w-4" />
          </button>
          <button
            onClick={() => onNavigate('dashboard')}
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-sm border border-white/10 transition-all hover:scale-[1.02]"
          >
            View Dashboard
          </button>
        </div>
      </section>

      {/* Interactive Terminal Component */}
      <section className="space-y-3">
        <div className="flex items-center justify-between text-xs text-slate-400 px-1 font-mono">
          <span className="flex items-center gap-1.5">
            <Server className="h-3.5 w-3.5 text-blue-400" />
            Live CLI Terminal Simulation (Real Engine)
          </span>
          <span className="text-emerald-400">Exit codes 0 / 1 strictly enforced</span>
        </div>
        <TerminalSimulator />
      </section>

      {/* Architectural Pillars */}
      <section className="grid md:grid-cols-3 gap-6">
        <div className="rounded-xl bg-[#111827]/60 border border-white/10 p-6 space-y-3 backdrop-blur-sm">
          <div className="h-10 w-10 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
            <Cpu className="h-5 w-5" />
          </div>
          <h3 className="text-lg font-bold text-white tracking-tight">Live Azure Retail API</h3>
          <p className="text-sm text-slate-400 leading-relaxed">
            Direct unauthenticated OData queries to <code className="text-xs text-blue-300">prices.azure.com</code>. 
            Filters out Spot and Low Priority meters to accurately capture standard Pay-as-You-Go rates.
          </p>
        </div>

        <div className="rounded-xl bg-[#111827]/60 border border-white/10 p-6 space-y-3 backdrop-blur-sm">
          <div className="h-10 w-10 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <Database className="h-5 w-5" />
          </div>
          <h3 className="text-lg font-bold text-white tracking-tight">SQLite Write-Through Cache</h3>
          <p className="text-sm text-slate-400 leading-relaxed">
            Eliminates redundant network queries. First run caches fetched SKU rates locally in SQLite; 
            subsequent runs execute with 100% cache hits in under 50 milliseconds.
          </p>
        </div>

        <div className="rounded-xl bg-[#111827]/60 border border-white/10 p-6 space-y-3 backdrop-blur-sm">
          <div className="h-10 w-10 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
            <Sliders className="h-5 w-5" />
          </div>
          <h3 className="text-lg font-bold text-white tracking-tight">Budget Circuit Breaker</h3>
          <p className="text-sm text-slate-400 leading-relaxed">
            CI/CD gatekeeper with deterministic exit codes: <code className="text-xs text-emerald-400">exit 0</code> within budget, 
            <code className="text-xs text-rose-400">exit 1</code> when budget breached, and <code className="text-xs text-amber-400">exit 2</code> on invalid input.
          </p>
        </div>
      </section>

      {/* How CostGuard Works Pipeline */}
      <section className="rounded-2xl bg-gradient-to-b from-[#111827] to-[#0D131F] border border-white/10 p-8 space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold text-white tracking-tight">How It Works</h2>
          <p className="text-sm text-slate-400">Continuous financial validation for Infrastructure-as-Code</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-white/5 border border-white/5 space-y-2">
            <span className="text-[10px] font-mono text-blue-400 font-bold uppercase">Step 01</span>
            <h4 className="font-semibold text-white text-sm">Terraform Plan JSON</h4>
            <p className="text-xs text-slate-400">Ingests compiled execution plans via CLI pipe (<code className="text-[11px] text-blue-300">stdin</code>) or explicit file flag.</p>
          </div>

          <div className="p-4 rounded-xl bg-white/5 border border-white/5 space-y-2">
            <span className="text-[10px] font-mono text-blue-400 font-bold uppercase">Step 02</span>
            <h4 className="font-semibold text-white text-sm">Resource Extractor</h4>
            <p className="text-xs text-slate-400">Detects create, update, delete, and replacement actions. Gracefully skips 15+ non-billable types.</p>
          </div>

          <div className="p-4 rounded-xl bg-white/5 border border-white/5 space-y-2">
            <span className="text-[10px] font-mono text-blue-400 font-bold uppercase">Step 03</span>
            <h4 className="font-semibold text-white text-sm">Tiered Pricing Engine</h4>
            <p className="text-xs text-slate-400">Checks SQLite first; calls Azure Retail Prices API on cache misses and persists rates for future lookups.</p>
          </div>

          <div className="p-4 rounded-xl bg-white/5 border border-white/5 space-y-2">
            <span className="text-[10px] font-mono text-blue-400 font-bold uppercase">Step 04</span>
            <h4 className="font-semibold text-white text-sm">Delta Math & Guardrail</h4>
            <p className="text-xs text-slate-400">Calculates 730-hour monthly costs, evaluates delta against budget threshold, and enforces exit code.</p>
          </div>
        </div>
      </section>
    </div>
  );
};