import React, { useState, useEffect } from 'react';
import { Search, RefreshCw, AlertTriangle } from 'lucide-react';
import { api } from '../services/api';

export const PricingExplorerPage: React.FC = () => {
  const [sku, setSku] = useState('Standard_B2s');
  const [region, setRegion] = useState('eastus');
  const [currency, setCurrency] = useState('USD');
  const [resourceType, setResourceType] = useState('virtual_machine');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const popularSkus = [
    { sku: 'Standard_B1s', type: 'virtual_machine', label: 'B1s (1 vCPU, 1GB)' },
    { sku: 'Standard_B2s', type: 'virtual_machine', label: 'B2s (2 vCPU, 4GB)' },
    { sku: 'Standard_D2s_v3', type: 'virtual_machine', label: 'D2s v3 (2 vCPU, 8GB)' },
    { sku: 'Standard_D4s_v5', type: 'virtual_machine', label: 'D4s v5 (4 vCPU, 16GB)' },
    { sku: 'Premium_SSD_Managed_Disk_P10', type: 'managed_disk', label: 'P10 Disk (128GB)' },
    { sku: 'Premium_SSD_Managed_Disk_P20', type: 'managed_disk', label: 'P20 Disk (512GB)' },
  ];

  const handleSearch = async (targetSku = sku, targetType = resourceType) => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const data = await api.getPricing(targetSku, region, currency, targetType);
      setResult(data);
    } catch (err: any) {
      setErrorMsg(err.message || 'Lookup failed');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    handleSearch('Standard_B2s', 'virtual_machine');
  }, []);

  return (
    <div className="space-y-8 max-w-6xl mx-auto pb-12">
      <div>
        <h2 className="text-2xl font-bold text-white tracking-tight">Azure Retail Pricing Explorer</h2>
        <p className="text-xs text-slate-400">Direct unauthenticated query against Microsoft Azure Retail Prices API with SQLite cache attribution.</p>
      </div>

      <div className="rounded-xl bg-[#111827]/80 border border-white/10 p-6 space-y-4 backdrop-blur-sm">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="md:col-span-2">
            <label className="block text-xs font-mono text-slate-400 mb-1">SKU / Meter Name</label>
            <div className="relative">
              <input
                type="text"
                value={sku}
                onChange={(e) => setSku(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                placeholder="e.g. Standard_B2s or Premium_SSD_Managed_Disk_P10"
                className="w-full bg-[#0D1117] border border-white/10 rounded-lg pl-9 pr-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-blue-500"
              />
              <Search className="h-4 w-4 text-slate-400 absolute left-3 top-2.5" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-400 mb-1">Azure Region</label>
            <select
              value={region}
              onChange={(e) => setRegion(e.target.value)}
              className="w-full bg-[#161B22] border border-white/10 rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-blue-500"
            >
              <option value="eastus">East US (eastus)</option>
              <option value="westeurope">West Europe (westeurope)</option>
              <option value="centralus">Central US (centralus)</option>
              <option value="northeurope">North Europe (northeurope)</option>
              <option value="uksouth">UK South (uksouth)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-400 mb-1">Currency</label>
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              className="w-full bg-[#161B22] border border-white/10 rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-blue-500"
            >
              <option value="USD">USD ($)</option>
              <option value="EUR">EUR (€)</option>
              <option value="GBP">GBP (£)</option>
              <option value="INR">INR (₹)</option>
            </select>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-white/5">
          <span className="text-[11px] text-slate-400 font-mono">Popular SKUs:</span>
          {popularSkus.map((ps, i) => (
            <button
              key={i}
              onClick={() => {
                setSku(ps.sku);
                setResourceType(ps.type);
                handleSearch(ps.sku, ps.type);
              }}
              className="px-2.5 py-1 rounded bg-white/5 hover:bg-white/10 border border-white/5 text-[11px] font-mono text-slate-300 hover:text-white transition-all"
            >
              {ps.label}
            </button>
          ))}
        </div>

        <button
          onClick={() => handleSearch()}
          disabled={loading}
          className="flex items-center justify-center gap-2 w-full py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-medium text-xs shadow-md shadow-blue-600/20 transition-all"
        >
          {loading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
          Query Azure Retail API
        </button>
      </div>

      {errorMsg && (
        <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center gap-2">
          <AlertTriangle className="h-4 w-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {result && result.rate && (
        <div className="rounded-xl bg-[#111827]/80 border border-white/10 p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
            <div>
              <div className="flex items-center gap-3">
                <h3 className="text-xl font-bold font-mono text-white tracking-tight">
                  {result.rate.sku}
                </h3>
                <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                  result.rate.source === 'CACHED'
                    ? 'bg-blue-500/10 text-blue-400 border-blue-500/20'
                    : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                }`}>
                  {result.rate.source === 'CACHED' ? 'CACHED (SQLite)' : 'LIVE API (Azure)'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1 font-mono">
                {result.rate.product_name} — Meter: {result.rate.meter_name}
              </p>
            </div>
            <div className="text-right">
              <span className="text-xs text-slate-400 block font-mono">Region</span>
              <span className="text-sm font-bold text-white font-mono uppercase">{result.rate.region}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-white/5 border border-white/5">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Hourly Unit Rate</span>
              <h4 className="text-2xl font-bold font-mono text-white mt-1">
                ${result.rate.hourly_rate.toFixed(4)}
              </h4>
              <span className="text-[11px] text-slate-400">per {result.rate.unit_of_measure}</span>
            </div>

            <div className="p-4 rounded-xl bg-white/5 border border-white/5">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Normalized Monthly Rate</span>
              <h4 className="text-2xl font-bold font-mono text-emerald-400 mt-1">
                ${result.rate.monthly_rate.toFixed(2)}
              </h4>
              <span className="text-[11px] text-slate-400">730 standard hours</span>
            </div>

            <div className="p-4 rounded-xl bg-white/5 border border-white/5">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Pricing Model</span>
              <h4 className="text-2xl font-bold font-mono text-blue-400 mt-1">
                Consumption
              </h4>
              <span className="text-[11px] text-slate-400">Non-Spot / Non-Low-Priority</span>
            </div>
          </div>

          {result.warning && (
            <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 shrink-0" />
              <span>{result.warning}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
