import React, { useState, useEffect } from 'react';
import { CheckCircle2, Save } from 'lucide-react';
import { api } from '../services/api';

export const GuardrailsPage: React.FC = () => {
  const [maxIncrease, setMaxIncrease] = useState(50.0);
  const [currency, setCurrency] = useState('USD');
  const [warningThreshold, setWarningThreshold] = useState(80.0);
  const [deploymentBlocking, setDeploymentBlocking] = useState(true);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api.getGuardrails().then((data) => {
      setMaxIncrease(data.max_increase);
      setWarningThreshold(data.warning_threshold_pct);
      setDeploymentBlocking(data.deployment_blocking);
    }).catch(console.error);
  }, []);

  const handleSave = async () => {
    setLoading(true);
    try {
      await api.updateGuardrails({
        max_increase: maxIncrease,
        currency,
        warning_threshold_pct: warningThreshold,
        deployment_blocking: deploymentBlocking,
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto pb-12">
      <div>
        <h2 className="text-2xl font-bold text-white tracking-tight">Policy Guardrails & Circuit Breaker</h2>
        <p className="text-xs text-slate-400">Configure financial spending ceilings and automated CI/CD deployment blocking.</p>
      </div>

      {saved && (
        <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs flex items-center gap-2">
          <CheckCircle2 className="h-4 w-4" />
          <span>Guardrail policy updated successfully.</span>
        </div>
      )}

      <div className="rounded-xl bg-[#111827]/80 border border-white/10 p-6 space-y-6">
        <h3 className="text-sm font-semibold text-white tracking-tight">Financial Ceiling Architecture</h3>

        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-emerald-400 font-bold">$0.00 SAFE ZONE</span>
            <span className="text-amber-400 font-bold">${(maxIncrease * (warningThreshold / 100)).toFixed(2)} WARNING ({warningThreshold}%)</span>
            <span className="text-rose-400 font-bold">${maxIncrease.toFixed(2)} BLOCKED</span>
          </div>

          <div className="w-full h-4 rounded-full overflow-hidden flex bg-slate-800">
            <div 
              style={{ width: warningThreshold + '%' }} 
              className="bg-gradient-to-r from-emerald-500 to-blue-500 h-full"
            />
            <div 
              style={{ width: (100 - warningThreshold) + '%' }} 
              className="bg-gradient-to-r from-amber-500 to-rose-500 h-full"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs pt-2">
            <div className="p-3 rounded-lg bg-white/5 border border-white/5 space-y-1">
              <span className="text-emerald-400 font-mono font-bold">1. Permitted Zone</span>
              <p className="text-[11px] text-slate-400">Changes below budget allowance exit code 0. Pull requests merge automatically.</p>
            </div>
            <div className="p-3 rounded-lg bg-white/5 border border-white/5 space-y-1">
              <span className="text-amber-400 font-mono font-bold">2. Warning Advisory</span>
              <p className="text-[11px] text-slate-400">Notifies reviewers when change approaches budget threshold.</p>
            </div>
            <div className="p-3 rounded-lg bg-white/5 border border-white/5 space-y-1">
              <span className="text-rose-400 font-mono font-bold">3. Circuit Breaker</span>
              <p className="text-[11px] text-slate-400">Strictly exits code 1, immediately terminating automated CI/CD deployment pipelines.</p>
            </div>
          </div>
        </div>
      </div>

      <div className="rounded-xl bg-[#111827]/80 border border-white/10 p-6 space-y-6">
        <h3 className="text-sm font-semibold text-white tracking-tight">Threshold Parameters</h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div>
            <label className="block text-xs font-mono text-slate-400 mb-2">
              Maximum Monthly Increase Allowed ($/month)
            </label>
            <input
              type="number"
              value={maxIncrease}
              onChange={(e) => setMaxIncrease(parseFloat(e.target.value) || 0)}
              className="w-full bg-[#0D1117] border border-white/10 rounded-lg px-4 py-2.5 text-sm text-white font-mono focus:outline-none focus:border-blue-500"
            />
            <p className="text-[11px] text-slate-400 mt-1">
              CLI flag: <code className="text-blue-300">--max-increase {maxIncrease}</code>
            </p>
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-400 mb-2">
              Advisory Warning Threshold (%)
            </label>
            <input
              type="number"
              value={warningThreshold}
              onChange={(e) => setWarningThreshold(parseFloat(e.target.value) || 0)}
              className="w-full bg-[#0D1117] border border-white/10 rounded-lg px-4 py-2.5 text-sm text-white font-mono focus:outline-none focus:border-blue-500"
            />
            <p className="text-[11px] text-slate-400 mt-1">Alerts when cost reaches {warningThreshold}% of budget limit.</p>
          </div>
        </div>

        <div className="pt-4 border-t border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="blockDeploy"
              checked={deploymentBlocking}
              onChange={(e) => setDeploymentBlocking(e.target.checked)}
              className="h-4 w-4 rounded accent-blue-600 cursor-pointer"
            />
            <label htmlFor="blockDeploy" className="text-xs text-slate-300 font-medium cursor-pointer">
              Enforce Strict Process Exit Code 1 on Budget Breach
            </label>
          </div>

          <button
            onClick={handleSave}
            disabled={loading}
            className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-bold font-mono transition-all shadow-md shadow-blue-600/20"
          >
            <Save className="h-3.5 w-3.5" />
            Save Policy
          </button>
        </div>
      </div>
    </div>
  );
};
