import React, { useState, useEffect } from 'react';
import { 
  DollarSign, 
  TrendingUp, 
  Server, 
  ShieldCheck, 
  Database, 
  Activity, 
  Play, 
  ArrowRight,
  CheckCircle2,
  XCircle
} from 'lucide-react';
import { MetricCard } from '../components/MetricCard';
import { api, PlanAnalysisResult } from '../services/api';

interface DashboardPageProps {
  onNavigate: (tab: string) => void;
  lastResult: PlanAnalysisResult | null;
  setLastResult: (result: PlanAnalysisResult) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  onNavigate,
  lastResult,
  setLastResult,
}) => {
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<any[]>([]);
  const [cacheStats, setCacheStats] = useState<any>(null);

  const fetchStatsAndHistory = async () => {
    try {
      const [hist, cache] = await Promise.all([
        api.getHistory(),
        api.getCache(1, 0),
      ]);
      setHistory(hist);
      setCacheStats(cache.stats);
    } catch (e) {
      console.error('Failed to load dashboard data', e);
    }
  };

  useEffect(() => {
    fetchStatsAndHistory();
    if (!lastResult) {
      api.analyzeDemo('plan_b', 50.0).then((res) => {
        setLastResult(res);
      }).catch(console.error);
    }
  }, []);

  const handleQuickRun = async (planKey: string, maxInc = 50.0) => {
    setLoading(true);
    try {
      const res = await api.analyzeDemo(planKey, maxInc);
      setLastResult(res);
      await fetchStatsAndHistory();
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const currentResult = lastResult || {
    prior_total: 15.18,
    projected_total: 50.08,
    net_delta: 34.90,
    items: [],
    verdict: { max_increase: 50.0, passed: true, status_text: 'PASSED', exit_code: 0, overage: 0 },
    cache_hits: 4,
    api_calls: 0,
    duration_ms: 12.4,
    skipped_resources: [],
    currency: 'USD',
  };

  const budgetRemaining = Math.max(0, currentResult.verdict.max_increase - currentResult.net_delta);
  const budgetUsagePct = currentResult.verdict.max_increase > 0 
    ? Math.min(100, Math.round((currentResult.net_delta / currentResult.verdict.max_increase) * 100))
    : 0;

  const netDeltaFormatted = (currentResult.net_delta >= 0 ? '+' : '-') + '$' + Math.abs(currentResult.net_delta).toFixed(2);

  return (
    <div className="space-y-8 max-w-6xl mx-auto pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">FinOps Operations Overview</h2>
          <p className="text-xs text-slate-400">Live infrastructure cost impact and budget telemetry.</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('analyze')}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium shadow-md shadow-blue-600/20 transition-all"
          >
            New Plan Analysis
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <MetricCard
          title="Projected Monthly Cost"
          value={'$' + currentResult.projected_total.toFixed(2)}
          delta={'Prior: $' + currentResult.prior_total.toFixed(2)}
          subtitle="730 hrs/mo"
          icon={DollarSign}
        />
        <MetricCard
          title="Monthly Net Delta"
          value={netDeltaFormatted}
          isPositiveDelta={currentResult.net_delta > 0}
          delta={currentResult.net_delta >= 0 ? 'Cost Increase' : 'Cost Savings'}
          subtitle="Budget gate signal"
          icon={TrendingUp}
        />
        <MetricCard
          title="Resources Changed"
          value={String(currentResult.items.length || 3)}
          subtitle={String(currentResult.skipped_resources.length) + ' non-billable skipped'}
          icon={Server}
        />
        <MetricCard
          title="Budget Remaining"
          value={'$' + budgetRemaining.toFixed(2)}
          badge={currentResult.verdict.passed ? 'SAFE' : 'BREACHED'}
          badgeColor={currentResult.verdict.passed ? 'green' : 'red'}
          subtitle={'Limit: +$' + currentResult.verdict.max_increase.toFixed(2) + '/mo'}
          icon={ShieldCheck}
        />
        <MetricCard
          title="Cache Hit Rate"
          value={(cacheStats?.hit_rate_pct ?? 75.0) + '%'}
          subtitle={(cacheStats?.total_entries ?? 4) + ' keys in SQLite'}
          icon={Database}
        />
        <MetricCard
          title="Azure API Calls"
          value={String(currentResult.api_calls)}
          subtitle={currentResult.cache_hits + ' cache hits saved'}
          icon={Activity}
        />
      </div>

      <div className="rounded-xl bg-[#111827]/80 border border-white/10 p-6 space-y-4 backdrop-blur-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <span className="text-xs font-mono uppercase text-slate-400">Budget Circuit Breaker Status</span>
            <div className="flex items-center gap-2 mt-1">
              {currentResult.verdict.passed ? (
                <span className="flex items-center gap-1.5 text-sm font-bold text-emerald-400">
                  <CheckCircle2 className="h-4 w-4" />
                  PASSED — Within Budget Allowance
                </span>
              ) : (
                <span className="flex items-center gap-1.5 text-sm font-bold text-rose-400">
                  <XCircle className="h-4 w-4" />
                  {'FAILED — Deployment Blocked (Over by +$' + currentResult.verdict.overage.toFixed(2) + '/mo)'}
                </span>
              )}
            </div>
          </div>
          <div className="text-right font-mono text-xs text-slate-300">
            <span>{'+$' + currentResult.net_delta.toFixed(2)}</span> / <span>{'+$' + currentResult.verdict.max_increase.toFixed(2) + '/mo'}</span>
            <span className="ml-2 px-2 py-0.5 rounded bg-white/5 border border-white/10 text-white font-bold">
              {budgetUsagePct}%
            </span>
          </div>
        </div>

        <div className="w-full bg-slate-800 rounded-full h-2.5 overflow-hidden">
          <div 
            className={'h-2.5 rounded-full transition-all duration-500 ' + (
              currentResult.verdict.passed 
                ? (budgetUsagePct > 80 ? 'bg-amber-500' : 'bg-blue-500')
                : 'bg-rose-500'
            )}
            style={{ width: Math.min(100, Math.max(5, budgetUsagePct)) + '%' }}
          />
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-semibold text-white tracking-tight">Run Standard Test Plans</h3>
          <span className="text-xs text-slate-400 font-mono">1-click automated validation</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div className="rounded-xl bg-[#111827]/60 border border-white/10 p-4 space-y-3 flex flex-col justify-between hover:border-blue-500/30 transition-all">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono uppercase text-blue-400 font-bold">Plan A</span>
                <span className="text-[10px] font-mono text-slate-400">2 items</span>
              </div>
              <h4 className="text-sm font-semibold text-white mt-1">The Small Add</h4>
              <p className="text-xs text-slate-400 mt-1">1 Linux VM (Standard_B1s) + 1 P10 Managed Disk in eastus.</p>
            </div>
            <button
              onClick={() => handleQuickRun('plan_a', 50.0)}
              disabled={loading}
              className="w-full flex items-center justify-center gap-1.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-slate-200 transition-all"
            >
              <Play className="h-3 w-3 text-blue-400" />
              Run Plan A
            </button>
          </div>

          <div className="rounded-xl bg-[#111827]/60 border border-white/10 p-4 space-y-3 flex flex-col justify-between hover:border-blue-500/30 transition-all">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono uppercase text-blue-400 font-bold">Plan B</span>
                <span className="text-[10px] font-mono text-slate-400">3 items</span>
              </div>
              <h4 className="text-sm font-semibold text-white mt-1">Upgrade & Delete</h4>
              <p className="text-xs text-slate-400 mt-1">Standard_B1s to B2s resize + P10 disk add + old VM delete.</p>
            </div>
            <button
              onClick={() => handleQuickRun('plan_b', 50.0)}
              disabled={loading}
              className="w-full flex items-center justify-center gap-1.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-slate-200 transition-all"
            >
              <Play className="h-3 w-3 text-blue-400" />
              Run Plan B
            </button>
          </div>

          <div className="rounded-xl bg-[#111827]/60 border border-white/10 p-4 space-y-3 flex flex-col justify-between hover:border-blue-500/30 transition-all">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono uppercase text-blue-400 font-bold">Plan C</span>
                <span className="text-[10px] font-mono text-slate-400">15 items</span>
              </div>
              <h4 className="text-sm font-semibold text-white mt-1">Hostile Noise Plan</h4>
              <p className="text-xs text-slate-400 mt-1">15 non-billable resources (VNet, Subnet, NSGs). $0 delta.</p>
            </div>
            <button
              onClick={() => handleQuickRun('plan_c', 50.0)}
              disabled={loading}
              className="w-full flex items-center justify-center gap-1.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-slate-200 transition-all"
            >
              <Play className="h-3 w-3 text-blue-400" />
              Run Plan C
            </button>
          </div>

          <div className="rounded-xl bg-[#111827]/60 border border-white/10 p-4 space-y-3 flex flex-col justify-between hover:border-blue-500/30 transition-all">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono uppercase text-blue-400 font-bold">Plan D</span>
                <span className="text-[10px] font-mono text-slate-400">1 item</span>
              </div>
              <h4 className="text-sm font-semibold text-white mt-1">Metadata-Only</h4>
              <p className="text-xs text-slate-400 mt-1">Tag updates only. Verified exact $0.00 financial delta.</p>
            </div>
            <button
              onClick={() => handleQuickRun('plan_d', 50.0)}
              disabled={loading}
              className="w-full flex items-center justify-center gap-1.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-slate-200 transition-all"
            >
              <Play className="h-3 w-3 text-blue-400" />
              Run Plan D
            </button>
          </div>
        </div>
      </div>

      <div className="rounded-xl bg-[#111827]/80 border border-white/10 overflow-hidden backdrop-blur-sm">
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white tracking-tight">Recent Execution History</h3>
          <span className="text-xs text-slate-400 font-mono">Last 5 runs</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-white/5 text-slate-400 uppercase font-mono">
              <tr>
                <th className="px-6 py-3">Timestamp</th>
                <th className="px-6 py-3">Resources</th>
                <th className="px-6 py-3">Prior Total</th>
                <th className="px-6 py-3">Projected Total</th>
                <th className="px-6 py-3">Net Delta</th>
                <th className="px-6 py-3">Cache Performance</th>
                <th className="px-6 py-3 text-right">Policy Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-slate-300">
              {history.length > 0 ? (
                history.slice(0, 5).map((h, i) => (
                  <tr key={i} className="hover:bg-white/5 transition-colors">
                    <td className="px-6 py-3 font-mono text-slate-400">
                      {new Date(h.timestamp * 1000).toLocaleTimeString()}
                    </td>
                    <td className="px-6 py-3 font-mono">{h.resources_count} changed</td>
                    <td className="px-6 py-3 font-mono">${h.prior_total.toFixed(2)}</td>
                    <td className="px-6 py-3 font-mono">${h.projected_total.toFixed(2)}</td>
                    <td className="px-6 py-3 font-mono font-semibold">
                      <span className={h.net_delta > 0 ? 'text-rose-400' : 'text-emerald-400'}>
                        {(h.net_delta >= 0 ? '+' : '-') + '$' + Math.abs(h.net_delta).toFixed(2)}
                      </span>
                    </td>
                    <td className="px-6 py-3 font-mono text-slate-400">
                      {h.cache_hits + ' hits / ' + h.api_calls + ' lookups (' + h.duration_ms + 'ms)'}
                    </td>
                    <td className="px-6 py-3 text-right">
                      <span className={'px-2 py-0.5 rounded text-[10px] font-mono border ' + (
                        h.passed 
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' 
                          : 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                      )}>
                        {h.passed ? 'PASSED (0)' : 'BLOCKED (1)'}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7} className="px-6 py-8 text-center text-slate-400 font-mono">
                    No prior runs in session. Run a demo plan above or upload a plan.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
