import React, { useState } from 'react';
import { 
  Upload, 
  FileText, 
  Play, 
  CheckCircle2, 
  AlertTriangle, 
  Activity, 
  ShieldAlert,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { api, PlanAnalysisResult } from '../services/api';

interface AnalyzePlanPageProps {
  onPlanAnalyzed: (result: PlanAnalysisResult) => void;
  lastResult: PlanAnalysisResult | null;
}

export const AnalyzePlanPage: React.FC<AnalyzePlanPageProps> = ({ onPlanAnalyzed, lastResult }) => {
  const [inputMode, setInputMode] = useState<'demo' | 'upload' | 'paste'>('demo');
  const [selectedDemo, setSelectedDemo] = useState<string>('plan_b');
  const [pastedJson, setPastedJson] = useState<string>('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const [maxIncrease, setMaxIncrease] = useState<number>(50.0);
  const [currency, setCurrency] = useState<string>('USD');
  const [useCache, setUseCache] = useState<boolean>(true);

  const [analyzing, setAnalyzing] = useState<boolean>(false);
  const [activeStage, setActiveStage] = useState<number>(0);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showSkipped, setShowSkipped] = useState<boolean>(false);

  const stages = [
    'Parsing Terraform plan JSON',
    'Extracting compute & storage resources',
    'Checking SQLite write-through cache',
    'Querying Azure Retail Prices API',
    'Calculating monthly figures (730 hrs)',
    'Evaluating budget guardrails',
  ];

  const handleAnalyze = async () => {
    setAnalyzing(true);
    setErrorMsg(null);
    setActiveStage(0);

    const stageInterval = setInterval(() => {
      setActiveStage((prev) => (prev < stages.length - 1 ? prev + 1 : prev));
    }, 180);

    try {
      let result: PlanAnalysisResult;

      if (inputMode === 'demo') {
        result = await api.analyzeDemo(selectedDemo, maxIncrease, currency, useCache);
      } else if (inputMode === 'upload') {
        if (!selectedFile) {
          throw new Error('Please select a Terraform plan JSON file to upload.');
        }
        result = await api.analyzeUpload(selectedFile, maxIncrease, currency, useCache);
      } else {
        if (!pastedJson.trim()) {
          throw new Error('Please paste Terraform plan JSON content.');
        }
        result = await api.analyzePlan({
          plan_json: pastedJson,
          max_increase: maxIncrease,
          currency,
          use_cache: useCache,
        });
      }

      clearInterval(stageInterval);
      setActiveStage(stages.length - 1);
      setTimeout(() => {
        onPlanAnalyzed(result);
        setAnalyzing(false);
      }, 250);
    } catch (err: any) {
      clearInterval(stageInterval);
      setErrorMsg(err.message || 'Analysis failed. Please check plan format.');
      setAnalyzing(false);
    }
  };

  const currentResult = lastResult;

  return (
    <div className="space-y-8 max-w-6xl mx-auto pb-12">
      <div>
        <h2 className="text-2xl font-bold text-white tracking-tight">Analyze Terraform Plan</h2>
        <p className="text-xs text-slate-400">Extract infrastructure changes and evaluate financial budget impact.</p>
      </div>

      <div className="rounded-xl bg-[#111827]/80 border border-white/10 p-6 space-y-6 backdrop-blur-sm">
        <div className="flex border-b border-white/10 pb-4 gap-2">
          <button
            onClick={() => setInputMode('demo')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-medium transition-all ${
              inputMode === 'demo'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Play className="h-3.5 w-3.5" />
            Standard Test Plans
          </button>
          <button
            onClick={() => setInputMode('upload')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-medium transition-all ${
              inputMode === 'upload'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Upload className="h-3.5 w-3.5" />
            Upload JSON File
          </button>
          <button
            onClick={() => setInputMode('paste')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-medium transition-all ${
              inputMode === 'paste'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <FileText className="h-3.5 w-3.5" />
            Paste Plan JSON
          </button>
        </div>

        {inputMode === 'demo' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              { id: 'plan_a', name: 'Plan A: The Small Add', desc: '1 VM (B1s) + 1 Disk (P10) in eastus. Expects +$27.30/mo.' },
              { id: 'plan_b', name: 'Plan B: Upgrade & Delete', desc: 'B1s to B2s resize + P10 add + delete B1s. Expects +$34.90/mo.' },
              { id: 'plan_c', name: 'Plan C: Hostile Noise', desc: '15 non-billable resources (VNets, NSGs, Subnets). Expects $0.00.' },
              { id: 'plan_d', name: 'Plan D: Metadata-Only', desc: 'Tag modifications only. Verified exact $0.00 delta.' },
            ].map((p) => (
              <div
                key={p.id}
                onClick={() => setSelectedDemo(p.id)}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  selectedDemo === p.id
                    ? 'bg-blue-600/10 border-blue-500 shadow-md shadow-blue-500/10'
                    : 'bg-white/5 border-white/5 hover:border-white/20'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-white text-xs">{p.name}</span>
                  <input
                    type="radio"
                    name="demoPlan"
                    checked={selectedDemo === p.id}
                    onChange={() => setSelectedDemo(p.id)}
                    className="accent-blue-500"
                  />
                </div>
                <p className="text-[11px] text-slate-400 mt-2 leading-relaxed">{p.desc}</p>
              </div>
            ))}
          </div>
        )}

        {inputMode === 'upload' && (
          <div className="border-2 border-dashed border-white/10 rounded-xl p-8 text-center hover:border-blue-500/50 transition-colors">
            <Upload className="h-8 w-8 text-slate-400 mx-auto mb-3" />
            <p className="text-sm text-slate-200 font-medium">
              {selectedFile ? selectedFile.name : 'Click to select or drag and drop Terraform Plan JSON'}
            </p>
            <p className="text-xs text-slate-400 mt-1">Output of terraform show -json tfplan.binary</p>
            <input
              type="file"
              accept=".json"
              onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
              className="mt-4 text-xs text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-500 cursor-pointer"
            />
          </div>
        )}

        {inputMode === 'paste' && (
          <div>
            <textarea
              rows={8}
              value={pastedJson}
              onChange={(e) => setPastedJson(e.target.value)}
              placeholder="Paste raw Terraform Plan JSON here (containing resource_changes[])..."
              className="w-full bg-[#0D1117] border border-white/10 rounded-xl p-4 text-xs font-mono text-slate-200 focus:outline-none focus:border-blue-500"
            />
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-white/10">
          <div>
            <label className="block text-xs font-mono text-slate-400 mb-1">
              Budget Max Increase ($/mo)
            </label>
            <input
              type="number"
              step="5"
              value={maxIncrease}
              onChange={(e) => setMaxIncrease(parseFloat(e.target.value) || 0)}
              className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-400 mb-1">
              Billing Currency
            </label>
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              className="w-full bg-[#161B22] border border-white/10 rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-blue-500"
            >
              <option value="USD">USD ($)</option>
              <option value="EUR">EUR (€)</option>
              <option value="GBP">GBP (£)</option>
              <option value="INR">INR (₹)</option>
            </select>
          </div>

          <div className="flex items-center pt-5">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={useCache}
                onChange={(e) => setUseCache(e.target.checked)}
                className="h-4 w-4 rounded accent-blue-600 bg-white/5 border-white/10"
              />
              <span className="text-xs text-slate-300 font-medium">Use SQLite Cache</span>
            </label>
          </div>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <button
          onClick={handleAnalyze}
          disabled={analyzing}
          className="w-full py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold text-sm tracking-wide shadow-lg shadow-blue-600/25 transition-all hover:scale-[1.01] active:scale-[0.99] flex items-center justify-center gap-2"
        >
          {analyzing ? (
            <>
              <Activity className="h-4 w-4 animate-spin" />
              ANALYZING INFRASTRUCTURE COST...
            </>
          ) : (
            <>
              <Play className="h-4 w-4 fill-white" />
              ANALYZE PLAN
            </>
          )}
        </button>

        {analyzing && (
          <div className="p-4 rounded-xl bg-black/40 border border-white/5 space-y-2">
            <p className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Analysis Execution Pipeline</p>
            {stages.map((stg, i) => (
              <div key={i} className="flex items-center gap-2 text-xs font-mono">
                {i < activeStage ? (
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400 shrink-0" />
                ) : i === activeStage ? (
                  <div className="h-3.5 w-3.5 rounded-full border-2 border-blue-400 border-t-transparent animate-spin shrink-0" />
                ) : (
                  <div className="h-3.5 w-3.5 rounded-full border border-slate-700 shrink-0" />
                )}
                <span className={i <= activeStage ? 'text-slate-200' : 'text-slate-400'}>
                  {stg}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {currentResult && !analyzing && (
        <div className="space-y-6">
          <div className={`rounded-xl p-6 border shadow-2xl ${
            currentResult.verdict.passed
              ? 'bg-emerald-950/20 border-emerald-500/30'
              : 'bg-rose-950/20 border-rose-500/30'
          }`}>
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-start gap-4">
                <div className={`p-3 rounded-xl ${
                  currentResult.verdict.passed
                    ? 'bg-emerald-500/20 text-emerald-400'
                    : 'bg-rose-500/20 text-rose-400'
                }`}>
                  {currentResult.verdict.passed ? (
                    <CheckCircle2 className="h-8 w-8" />
                  ) : (
                    <ShieldAlert className="h-8 w-8" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className={`text-xl font-bold font-mono tracking-tight ${
                      currentResult.verdict.passed ? 'text-emerald-400' : 'text-rose-400'
                    }`}>
                      {currentResult.verdict.passed ? 'PASSED (0)' : 'BUDGET EXCEEDED (1)'}
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded bg-white/5 text-slate-300 font-mono">
                      Gate Enforced
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1">
                    {currentResult.verdict.status_text}
                  </p>
                  {!currentResult.verdict.passed && (
                    <p className="text-xs text-rose-400 font-mono font-semibold mt-1">
                      [CIRCUIT BREAKER] CostGuard: Budget threshold breached. Deployment blocked.
                    </p>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-slate-400 bg-white/5 p-3 rounded-lg border border-white/5">
                <div>
                  <span className="text-slate-400 block text-[10px]">EXECUTION TIME</span>
                  <span className="text-slate-200 font-semibold">{currentResult.duration_ms} ms</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">CACHE PERFORMANCE</span>
                  <span className="text-slate-200 font-semibold">{currentResult.cache_hits} hits / {currentResult.api_calls} lookups</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">CIRCUIT BREAKER</span>
                  <span className={currentResult.verdict.passed ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold'}>
                    +{currentResult.verdict.max_increase.toFixed(2)}/mo
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-[#111827]/80 border border-white/10">
              <span className="text-[11px] font-mono text-slate-400 uppercase">Prior Monthly Cost</span>
              <h3 className="text-2xl font-bold font-mono text-white mt-1">
                ${currentResult.prior_total.toFixed(2)}
              </h3>
              <span className="text-[11px] text-slate-400">Baseline before plan</span>
            </div>

            <div className="p-4 rounded-xl bg-[#111827]/80 border border-white/10">
              <span className="text-[11px] font-mono text-slate-400 uppercase">Projected Monthly Cost</span>
              <h3 className="text-2xl font-bold font-mono text-white mt-1">
                ${currentResult.projected_total.toFixed(2)}
              </h3>
              <span className="text-[11px] text-slate-400">730 standard hours</span>
            </div>

            <div className="p-4 rounded-xl bg-[#111827]/80 border border-white/10">
              <span className="text-[11px] font-mono text-slate-400 uppercase">Net Monthly Impact</span>
              <h3 className={`text-2xl font-bold font-mono mt-1 ${
                currentResult.net_delta > 0 ? 'text-rose-400' : 'text-emerald-400'
              }`}>
                {currentResult.net_delta >= 0 ? '+' : '-'}${Math.abs(currentResult.net_delta).toFixed(2)}
              </h3>
              <span className="text-[11px] text-slate-400">Monthly budget change</span>
            </div>
          </div>

          <div className="rounded-xl bg-[#111827]/80 border border-white/10 overflow-hidden">
            <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white tracking-tight">Resource Cost Breakdown</h3>
              <span className="text-xs text-slate-400 font-mono">{currentResult.items.length} billable items</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-white/5 text-slate-400 uppercase font-mono">
                  <tr>
                    <th className="px-6 py-3">Resource Address</th>
                    <th className="px-6 py-3">Action</th>
                    <th className="px-6 py-3">Region</th>
                    <th className="px-6 py-3">SKU / Meter</th>
                    <th className="px-6 py-3 text-right">Old ($/mo)</th>
                    <th className="px-6 py-3 text-right">New ($/mo)</th>
                    <th className="px-6 py-3 text-right">Delta ($/mo)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-slate-300">
                  {currentResult.items.map((it, idx) => {
                    const act = it.action.toUpperCase();
                    let actBadge = 'bg-blue-500/10 text-blue-400 border-blue-500/20';
                    if (act === 'CREATE') actBadge = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
                    else if (act === 'DELETE') actBadge = 'bg-rose-500/10 text-rose-400 border-rose-500/20';
                    else if (act === 'UPDATE') actBadge = 'bg-amber-500/10 text-amber-400 border-amber-500/20';

                    return (
                      <tr key={idx} className="hover:bg-white/5 transition-colors">
                        <td className="px-6 py-3.5 font-mono text-cyan-300">
                          {it.address}
                        </td>
                        <td className="px-6 py-3.5">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-mono border font-semibold ${actBadge}`}>
                            {act}
                          </span>
                        </td>
                        <td className="px-6 py-3.5 font-mono text-slate-400">
                          {it.region}
                        </td>
                        <td className="px-6 py-3.5 font-mono text-slate-200">
                          {it.display_sku}
                        </td>
                        <td className="px-6 py-3.5 text-right font-mono text-slate-400">
                          ${it.old_monthly.toFixed(2)}
                        </td>
                        <td className="px-6 py-3.5 text-right font-mono text-slate-200">
                          ${it.new_monthly.toFixed(2)}
                        </td>
                        <td className="px-6 py-3.5 text-right font-mono font-bold">
                          <span className={it.delta_monthly > 0 ? 'text-rose-400' : it.delta_monthly < 0 ? 'text-emerald-400' : 'text-slate-400'}>
                            {it.delta_monthly >= 0 ? '+' : '-'}${Math.abs(it.delta_monthly).toFixed(2)}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {currentResult.skipped_resources.length > 0 && (
            <div className="rounded-xl bg-white/5 border border-white/5 p-4 text-xs font-mono">
              <div 
                className="flex items-center justify-between cursor-pointer select-none"
                onClick={() => setShowSkipped(!showSkipped)}
              >
                <div className="flex items-center gap-2 text-slate-400">
                  <CheckCircle2 className="h-4 w-4 text-blue-400" />
                  <span>
                    Gracefully skipped <strong className="text-white">{currentResult.skipped_resources.length}</strong> non-billable resources without crashing.
                  </span>
                </div>
                <button className="text-slate-400 hover:text-white">
                  {showSkipped ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </button>
              </div>

              {showSkipped && (
                <div className="mt-3 pt-3 border-t border-white/5 space-y-1 text-slate-400">
                  {currentResult.skipped_resources.map((sk, sidx) => (
                    <div key={sidx} className="flex items-center gap-2">
                      <span className="text-slate-400">[INFO]</span>
                      <span className="text-slate-300">{sk.address}</span>
                      <span className="text-[10px] text-slate-400">({sk.reason})</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
