import React, { useState, useEffect } from 'react';
import { Play, CheckCircle2, Clock } from 'lucide-react';
import { api, PlanAnalysisResult, TestPlanInfo } from '../services/api';

interface TestPlansPageProps {
  onPlanAnalyzed: (result: PlanAnalysisResult) => void;
}

export const TestPlansPage: React.FC<TestPlansPageProps> = ({ onPlanAnalyzed }) => {
  const [plans, setPlans] = useState<TestPlanInfo[]>([]);
  const [runningPlan, setRunningPlan] = useState<string | null>(null);
  const [testResults, setTestResults] = useState<Record<string, PlanAnalysisResult>>({});

  useEffect(() => {
    api.getTestPlans().then(setPlans).catch(console.error);
  }, []);

  const runTest = async (planId: string) => {
    setRunningPlan(planId);
    try {
      const res = await api.runTestPlan(planId, 50.0);
      setTestResults((prev) => ({ ...prev, [planId]: res }));
      onPlanAnalyzed(res);
    } catch (e) {
      console.error(e);
    } finally {
      setRunningPlan(null);
    }
  };

  const runAllTests = async () => {
    for (const p of plans) {
      await runTest(p.id);
    }
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Test Scenario Runner</h2>
          <p className="text-xs text-slate-400">Deterministic verification against the 4 student handout benchmark test plans.</p>
        </div>
        <button
          onClick={runAllTests}
          disabled={runningPlan !== null}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-bold font-mono transition-all shadow-md shadow-blue-600/20"
        >
          <Play className="h-3.5 w-3.5" />
          Run All Test Plans
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {plans.map((p) => {
          const res = testResults[p.id];
          const isRunning = runningPlan === p.id;

          return (
            <div
              key={p.id}
              className="rounded-xl bg-[#111827]/80 border border-white/10 p-6 space-y-4 backdrop-blur-sm flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold uppercase text-blue-400">
                    {p.id.replace('_', ' ').toUpperCase()}
                  </span>
                  <span className="text-[10px] font-mono text-slate-400 bg-white/5 px-2 py-0.5 rounded border border-white/5">
                    {p.resource_count} resource changes
                  </span>
                </div>

                <h3 className="text-base font-bold text-white tracking-tight">{p.title}</h3>
                <p className="text-xs text-slate-300 leading-relaxed">{p.description}</p>
                <div className="p-3 rounded-lg bg-white/5 border border-white/5 text-[11px] text-slate-400 font-mono">
                  <strong className="text-slate-200">Expected:</strong> {p.expected_behavior}
                </div>
              </div>

              {res ? (
                <div className="pt-3 border-t border-white/10 space-y-3">
                  <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
                    <span className="flex items-center gap-1.5 text-emerald-400">
                      <CheckCircle2 className="h-3.5 w-3.5" /> Plan Parsed
                    </span>
                    <span className="flex items-center gap-1.5 text-emerald-400">
                      <CheckCircle2 className="h-3.5 w-3.5" /> Sizing Extracted
                    </span>
                    <span className="flex items-center gap-1.5 text-emerald-400">
                      <CheckCircle2 className="h-3.5 w-3.5" /> Azure Priced
                    </span>
                    <span className="flex items-center gap-1.5 text-emerald-400">
                      <CheckCircle2 className="h-3.5 w-3.5" /> SQLite Cached
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-3 rounded-lg bg-black/40 border border-white/5 text-xs font-mono">
                    <div>
                      <span className="text-slate-400 block text-[10px]">NET MONTHLY DELTA</span>
                      <span className={`text-sm font-bold ${res.net_delta > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                        {res.net_delta >= 0 ? '+' : '-'}${Math.abs(res.net_delta).toFixed(2)}/mo
                      </span>
                    </div>

                    <div>
                      <span className="text-slate-400 block text-[10px]">DURATION / CACHE</span>
                      <span className="text-slate-200">{res.duration_ms}ms ({res.cache_hits} hits)</span>
                    </div>

                    <div className="text-right">
                      <span className="text-slate-400 block text-[10px]">VERDICT</span>
                      <span className={`font-bold ${res.verdict.passed ? 'text-emerald-400' : 'text-rose-400'}`}>
                        EXIT {res.verdict.exit_code} ({res.verdict.passed ? 'PASS' : 'FAIL'})
                      </span>
                    </div>
                  </div>
                </div>
              ) : null}

              <button
                onClick={() => runTest(p.id)}
                disabled={isRunning}
                className="w-full mt-2 flex items-center justify-center gap-2 py-2.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-slate-200 transition-all"
              >
                {isRunning ? (
                  <>
                    <Clock className="h-3.5 w-3.5 animate-spin text-blue-400" />
                    Executing Test...
                  </>
                ) : (
                  <>
                    <Play className="h-3.5 w-3.5 text-blue-400" />
                    Run Test Scenario
                  </>
                )}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
