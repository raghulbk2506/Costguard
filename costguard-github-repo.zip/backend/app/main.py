﻿"""FastAPI Application entrypoint for CostGuard."""

import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from backend.app.routes import router


app = FastAPI(
    title="CostGuard API",
    description="Infrastructure Cost Impact Predictor Using Live Azure Retail Prices and Embedded SQLite Cache.",
    version="1.0.0",
)

# Enable CORS for local dev servers (Vite runs on 5173 or similar)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)

# Serve built frontend if dist exists
dist_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "frontend", "dist"))
if os.path.exists(dist_dir):
    app.mount("/assets", StaticFiles(directory=os.path.join(dist_dir, "assets")), name="assets")

    @app.get("/{full_path:path}")
    async def serve_spa(full_path: str):
        file_path = os.path.join(dist_dir, full_path)
        if os.path.exists(file_path) and os.path.isfile(file_path):
            return FileResponse(file_path)
        return FileResponse(os.path.join(dist_dir, "index.html"))
else:
    @app.get("/")
    def index():
        return {
            "name": "CostGuard API",
            "docs": "/docs",
            "status": "operational",
            "message": "Use /api endpoints or run the Vite frontend development server.",
        }
