"""FastAPI route definitions for CostGuard API."""

import json
import os
import time
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, File, HTTPException, Query, UploadFile
from pydantic import BaseModel, Field

from costguard.core.cache import PricingCache
from costguard.core.calculator import CostCalculator
from costguard.core.guardrail import BudgetGuardrail
from costguard.core.models import CacheStats, PlanAnalysisResult, PriceRate
from costguard.core.parser import ParserError, TerraformPlanParser
from costguard.core.pricing import AzurePricingEngine


router = APIRouter(prefix="/api")

# Singletons for backend
pricing_cache = PricingCache()
pricing_engine = AzurePricingEngine(cache=pricing_cache)
calculator = CostCalculator(pricing_engine=pricing_engine)
default_guardrail = BudgetGuardrail(max_increase=50.0, warning_pct=80.0)

# In-memory history of recent analyses
analysis_history: List[Dict[str, Any]] = []

TEST_PLANS_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "test-plans"))


class AnalyzeRequest(BaseModel):
    plan_json: Any
    max_increase: float = 50.0
    currency: str = "USD"
    use_cache: bool = True


class GuardrailSettings(BaseModel):
    max_increase: float = 50.0
    currency: str = "USD"
    warning_threshold_pct: float = 80.0
    deployment_blocking: bool = True


@router.get("/health")
def health():
    stats = pricing_cache.get_stats()
    return {
        "status": "ok",
        "service": "CostGuard API",
        "version": "1.0.0",
        "cached_entries": stats.total_entries,
        "engine": "Azure Retail Prices + SQLite Cache",
    }


@router.post("/analyze", response_model=PlanAnalysisResult)
def analyze_plan_payload(req: AnalyzeRequest):
    """Analyze a raw JSON string or object payload."""
    try:
        if isinstance(req.plan_json, str):
            plan_dict = TerraformPlanParser.parse_json(req.plan_json)
        elif isinstance(req.plan_json, dict):
            plan_dict = req.plan_json
        else:
            raise HTTPException(status_code=400, detail="Invalid plan payload: must be JSON string or object.")

        billable, skipped = TerraformPlanParser.parse_plan(plan_dict)
    except ParserError as pe:
        raise HTTPException(status_code=400, detail=str(pe))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Parsing failure: {str(e)}")

    result = calculator.analyze_plan(
        billable_resources=billable,
        skipped_resources=skipped,
        max_increase=req.max_increase,
        currency=req.currency,
        use_cache=req.use_cache,
    )

    # Record history item
    history_entry = {
        "id": f"analysis_{int(time.time() * 1000)}",
        "timestamp": int(time.time()),
        "resources_count": len(result.items),
        "prior_total": result.prior_total,
        "projected_total": result.projected_total,
        "net_delta": result.net_delta,
        "passed": result.verdict.passed,
        "currency": result.currency,
        "cache_hits": result.cache_hits,
        "api_calls": result.api_calls,
        "duration_ms": result.duration_ms,
    }
    analysis_history.insert(0, history_entry)
    if len(analysis_history) > 50:
        analysis_history.pop()

    return result


@router.post("/analyze/upload", response_model=PlanAnalysisResult)
async def analyze_plan_file(
    file: UploadFile = File(...),
    max_increase: float = 50.0,
    currency: str = "USD",
    use_cache: bool = True,
):
    """Upload a Terraform plan JSON file and analyze it."""
    try:
        content = await file.read()
        text = content.decode("utf-8")
        plan_dict = TerraformPlanParser.parse_json(text)
        billable, skipped = TerraformPlanParser.parse_plan(plan_dict)
    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail="Uploaded file must be UTF-8 encoded JSON.")
    except ParserError as pe:
        raise HTTPException(status_code=400, detail=str(pe))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to parse uploaded file: {str(e)}")

    result = calculator.analyze_plan(
        billable_resources=billable,
        skipped_resources=skipped,
        max_increase=max_increase,
        currency=currency,
        use_cache=use_cache,
    )
    return result


@router.post("/analyze/demo/{plan_name}", response_model=PlanAnalysisResult)
def analyze_demo_plan(
    plan_name: str,
    max_increase: float = 50.0,
    currency: str = "USD",
    use_cache: bool = True,
):
    """Analyze one of the built-in demo test plans."""
    valid_names = {
        "plan_a": "plan_a_small_add.json",
        "plan_a.json": "plan_a_small_add.json",
        "plan_a_small_add": "plan_a_small_add.json",
        "plan_a_small_add.json": "plan_a_small_add.json",
        "plan_b": "plan_b_upgrade_delete.json",
        "plan_b.json": "plan_b_upgrade_delete.json",
        "plan_b_upgrade_delete": "plan_b_upgrade_delete.json",
        "plan_b_upgrade_delete.json": "plan_b_upgrade_delete.json",
        "plan_c": "plan_c_hostile_noise.json",
        "plan_c.json": "plan_c_hostile_noise.json",
        "plan_c_hostile_noise": "plan_c_hostile_noise.json",
        "plan_c_hostile_noise.json": "plan_c_hostile_noise.json",
        "plan_d": "plan_d_metadata_only.json",
        "plan_d.json": "plan_d_metadata_only.json",
        "plan_d_metadata_only": "plan_d_metadata_only.json",
        "plan_d_metadata_only.json": "plan_d_metadata_only.json",
    }
    filename = valid_names.get(plan_name.lower())
    if not filename:
        raise HTTPException(status_code=404, detail=f"Demo plan '{plan_name}' not found. Available: {list(valid_names.keys())}")

    filepath = os.path.join(TEST_PLANS_DIR, filename)
    if not os.path.exists(filepath):
        raise HTTPException(status_code=404, detail=f"Plan fixture '{filename}' not found on server disk.")

    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

    plan_dict = TerraformPlanParser.parse_json(content)
    billable, skipped = TerraformPlanParser.parse_plan(plan_dict)

    result = calculator.analyze_plan(
        billable_resources=billable,
        skipped_resources=skipped,
        max_increase=max_increase,
        currency=currency,
        use_cache=use_cache,
    )
    return result


@router.get("/cache")
def get_cache_info(
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    search: Optional[str] = None,
):
    stats = pricing_cache.get_stats()
    entries = pricing_cache.get_all(limit=limit, offset=offset, search=search)
    return {
        "stats": stats,
        "entries": entries,
        "limit": limit,
        "offset": offset,
    }


@router.delete("/cache")
def clear_cache():
    deleted = pricing_cache.clear()
    return {"message": f"Successfully cleared {deleted} cache entries.", "deleted_count": deleted}


@router.get("/pricing")
def search_pricing(
    sku: str = Query(default="Standard_B1s"),
    region: str = Query(default="eastus"),
    currency: str = Query(default="USD"),
    resource_type: str = Query(default="virtual_machine"),
    os_type: str = Query(default="Linux"),
):
    """Query price for a SKU in a region, checking cache then live Azure API."""
    rate, warn = pricing_engine.get_price(
        sku=sku,
        region=region,
        currency=currency,
        os_type=os_type,
        resource_type=resource_type,
        use_cache=True,
    )
    return {
        "rate": rate,
        "warning": warn,
    }


@router.get("/pricing/{sku}")
def get_sku_pricing(
    sku: str,
    region: str = Query(default="eastus"),
    currency: str = Query(default="USD"),
):
    rate, warn = pricing_engine.get_price(sku=sku, region=region, currency=currency)
    return {"rate": rate, "warning": warn}


@router.get("/guardrails")
def get_guardrails():
    return {
        "max_increase": default_guardrail.max_increase,
        "warning_threshold_pct": default_guardrail.warning_pct,
        "deployment_blocking": True,
        "default_currency": "USD",
    }


@router.put("/guardrails")
def update_guardrails(settings: GuardrailSettings):
    default_guardrail.max_increase = settings.max_increase
    default_guardrail.warning_pct = settings.warning_threshold_pct
    return {
        "message": "Guardrail settings updated successfully.",
        "settings": settings,
    }


@router.get("/test-plans")
def list_test_plans():
    plans = [
        {
            "id": "plan_a",
            "filename": "plan_a_small_add.json",
            "title": "Plan A — The Small Add",
            "description": "Provisions 1 new Linux VM (Standard_B1s) and 1 Managed Disk (P10 128GB) in eastus.",
            "expected_behavior": "Net-new resource creation with +$27.30/mo delta. Passes $50 budget.",
            "resource_count": 2,
        },
        {
            "id": "plan_b",
            "filename": "plan_b_upgrade_delete.json",
            "title": "Plan B — The Upgrade & Delete",
            "description": "Resizes VM from Standard_B1s to Standard_B2s, adds P10 disk, and deletes an unneeded VM.",
            "expected_behavior": "Calculates combined upgrade, addition, and deletion. Net +$34.90/mo delta.",
            "resource_count": 3,
        },
        {
            "id": "plan_c",
            "filename": "plan_c_hostile_noise.json",
            "title": "Plan C — The Hostile Noise Plan",
            "description": "Contains 15 non-billable Azure resources (VNet, Subnets, NSGs, Route Tables) and 0 compute.",
            "expected_behavior": "Skips all free resources gracefully without crashing. Exact $0.00 delta.",
            "resource_count": 15,
        },
        {
            "id": "plan_d",
            "filename": "plan_d_metadata_only.json",
            "title": "Plan D — Metadata-Only Changes",
            "description": "Updates VM tags and configuration parameters without altering size or location.",
            "expected_behavior": "Zero net impact ($0.00 delta) on infrastructure costs.",
            "resource_count": 1,
        },
    ]
    return plans


@router.post("/test-plans/{plan_name}/run")
def run_test_plan(plan_name: str, max_increase: float = 50.0):
    return analyze_demo_plan(plan_name=plan_name, max_increase=max_increase)


@router.get("/history")
def get_history():
    return analysis_history


@router.get("/report")
def get_report():
    """Generate summary data and markdown report."""
    stats = pricing_cache.get_stats()
    return {
        "stats": stats,
        "recent_runs": len(analysis_history),
        "circuit_breaker": {
            "default_limit": default_guardrail.max_increase,
            "status": "ACTIVE",
        },
    }
